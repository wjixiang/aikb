# Taking ACE inhibitors during early pregnancy Is it safe?

Joel G. Ray MD MSc FRCPC Marian J. Vermeulen MHSc Gideon Koren MD FRCPC

# ABSTRACT

QUESTION I knew that angiotensin-converting enzyme (ACE) inhibitors were risky to use during late pregnancy because they can cause renal shutdown in the fetus. Recently I heard of a study that claimed first-trimester exposure (when many patients still are unaware of their pregnancies) can also cause major malformations. Is this proven?

ANSWER A recent study did suggest an increased risk of malformations after first-trimester exposure to ACE inhibitors among women treated for hypertension. We believe this study had serious limitations that preclude drawing any conclusions at present.

# RÉSUMÉ

QUESTION Je connaissais les risques d’utiliser des inhibiteurs de l’enzyme de conversion de l’angiotensine (ECA) durant la fin de la grossesse, parce qu’ils peuvent causer l’arrêt de la fonction rénale chez le fœtus. J’ai récemment entendu dire que l’exposition durant le premier trimestre (lorsque de nombreuses patientes ne savent pas encore qu’elles sont enceintes) peut aussi causer des malformations majeures. Est-ce démontré?

RÉPONSE Une récente étude fait effectivement valoir un risque accru de malformations après l’exposition à des inhibiteurs de l’ECA durant le premier trimestre chez des femmes traitées pour l’hypertension. Nous croyons que cette étude comporte de sérieuses limites qui nous empêchent de tirer des conclusions à l’heure actuelle.

t is well accepted that angiotensin-converting enzyme I(ACE) inhibitors are contraindicated during the second and third trimesters of pregnancy because of increased risk of fetal renal damage. First-trimester use, however, has not been linked to adverse fetal outcomes.

Cooper and colleagues conducted a study to assess the association between exposure to ACE inhibitors during the first trimester of pregnancy and risk of congenital malformations.1 They followed a cohort of 29507 infants from Tennessee Medicaid files who were born between 1985 and 2000 and whose mothers had no evidence of having had diabetes. The researchers identified 209 infants who had been exposed to ACE inhibitors during the first trimester only, 202 infants who had been exposed to other antihypertensive medications during the first trimester only, and 29096 infants who had not been exposed to antihypertensive drugs. Infants who had been exposed to ACE inhibitors had a greater risk of major congenital malformations (risk ratio 2.71, $9 5 \%$ confidence interval [CI] 1.72 to 4.27) than did infants not exposed to antihypertensive medications. Being exposed to other antihypertensive medications did not result in an increased risk of major malformations (risk ratio 0.66, $9 5 \%$ CI 0.25 to 1.75). Infants exposed to ACE inhibitors were at increased risk of malformations of the cardiovascular system (risk ratio 3.72, $9 5 \%$ CI 1.89 to 7.30) and the central nervous system (risk ratio 4.39, $9 5 \%$ CI 1.37 to 14.02). The authors concluded that exposure to ACE inhibitors during the first trimester cannot be considered safe and should be avoided.

# Confounding effects

We have some serious reservations about the findings of Cooper and colleagues.1 We think it likely that these findings were affected by unrealized confounding and ascertainment bias. Clinicians and women considering pregnancy should both be dissuaded from following the authors’ recommendation that ACE inhibitors be avoided during the first trimester of pregnancy. While the authors excluded women treated pharmacologically or hospitalized for diabetes mellitus (DM), they could not exclude women with undiagnosed or dietcontrolled type 2 DM who, combined, represent more than half of all young women with type 2 DM.2,3 Also, Cooper and colleagues did not adjust for prepregnancy body mass, a major predictor of risk of both type 2 DM and hypertension and a probable risk factor for fetal congenital anomalies.4,5 The specific use of an ACE inhibitor (versus another antihypertensive medication6,7) might be directly related to these unmeasured and important confounding factors. The fact that most birth defects in the group exposed to ACE inhibitors were cardiac, for which maternal DM is a known risk factor,8 would support this notion.

# Motherisk Update

Another thing to consider is that the women prescribed ACE inhibitors were 3 years older on average than the women receiving other antihypertensive medications and 6 years older than those taking no medications. Because maternal age is directly related to the risk of congenital anomalies, even in the absence of aneuploidy,9 and is also a risk factor for both type 2 DM and hypertension, unmeasured confounding might once again explain the authors’ findings, despite their adjustment for maternal age.

Finally, using birth-certificate data alone to capture fetal anomalies, as was the case in their study, introduces ascertainment bias, as about half of all pregnancies affected by major fetal anomalies are terminated.10-12 Missing a substantial number of terminated pregnancies would cloud any true relationship between use of ACE inhibitors and many major anomalies.

# We recommend

These findings might discourage young, non-pregnant women from achieving adequate blood pressure control with ACE inhibitors, for which there is level I evidence of protection against cardiovascular and renal disease. Other published studies have not found an association between first-trimester exposure to ACE inhibitors and fetal anomalies.13 Until proven otherwise, we believe that ACE inhibitors should not be presented as teratogenic when taken during the first trimester of pregnancy. Patients should switch to another medication (eg, labetalol or alpha-methyldopa) before they go into the second trimester of pregnancy.13 \*

# References

1. Cooper WO, Hernandez-Diaz S, Arbogast PG, Dudley JA, Dyer S, Gideon PS, et al. Major congenital malformations after first-trimester exposure to ACE inhibitors. N Engl J Med 2006;354:2443-51.   
2. Gregg EW, Cadwell BL, Cheng YJ, Cowie CC, Williams DE, Geiss L, et al. Trends in the prevalence and ratio of diagnosed to undiagnosed diabetes according to obesity levels in the U.S. Diabetes Care 2004;27(12):2806-12.   
3. Hippisley-Cox J, Pringle M. Prevalence, care, and outcomes for patients with diet-controlled diabetes in general practice: cross sectional survey. Lancet   
2004;364:423-8.   
4. Prentice A, Goldberg G. Maternal obesity increases congenital malformations. Nutr Rev 1996;54:146-50.   
5. Cedergren MI, Kallen BA. Maternal obesity and infant heart defects. Obes Res 2003;11:1065-71.   
6. Kaplan NM. Management of hypertension in patients with type 2 diabetes mellitus: guidelines based on current evidence. Ann Intern Med 2001;135:1079-83.   
7. Working Party of the International Diabetes Federation (European Region). Hypertension in people with type 2 diabetes: knowledge-based diabetes-specific guidelines. Diabet Med 2003;20:972-87.   
8. McLeod L, Ray JG. Prevention and detection of diabetic embryopathy. Community Genet 2002;5:33-9.   
9. Hollier LM, Leveno KJ, Kelly MA, McIntire DD, Cunningham FG. Maternal age and malformations in singleton births. Obstet Gynecol 2000;96:701-6.   
10. Peller AJ, Westgate MN, Holmes LB. Trends in congenital malformations, 1974-1999: effect of prenatal diagnosis and elective termination. Obstet Gynecol 2004;104:957-64.   
11. Davidson N, Halliday J, Riley M, King J. Influence of prenatal diagnosis and pregnancy termination of fetuses with birth defects on the perinatal mortality rate in Victoria, Australia. Paediatr Perinat Epidemiol 2005;19:50-5.   
12. Van Allen MI, Boyle E, Thiessen P, MFadden D, Cochrane D, Chambers GK, et al. The impact of prenatal diagnosis on neural tube defect (NTD) pregnancy versus birth incidence in British Columbia. J Appl Genet 2006;47:151-8.   
13. Burrows RF, Burrows EA. Assessing the teratogenic potential of angiotensin-converting enzyme inhibitors in pregnancy. Aust N Z J Obstet Gynaecol 1998;38:306-11.

# MOTHERISK

Motherisk questions are prepared by the Motherisk Team at the Hospital for Sick Children in Toronto, Ont. Dr Ray is from the Departments of Medicine and Obstetrics and Gynecology and Ms Vermeulen is from the Institute for Clinical Evaluative Sciences, both at the University of Toronto, and Dr Koren is Director of the Motherisk Program. Dr Koren is supported by the Research Leadership for Better Pharmacotherapy during Pregnancy and Lactation and, in part, by a grant from the Canadian Institutes of Health Research. He holds the Ivey Chair in Molecular Toxicology at the University of Western Ontario in London.

Do you have questions about the effects of drugs, chemicals, radiation, or infections in women who are pregnant or breastfeeding? We invite you to submit them to the Motherisk Program by fax at 416 813-7562; they will be addressed in future Motherisk Updates.

Published Motherisk Updates are available on the Canadian Family Physician website (www.cfp.ca) and also on the Motherisk website (www.motherisk.org).