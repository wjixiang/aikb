JAMA | Review

# Evaluating the Patient With a Pulmonary Nodule A Review

Peter J. Mazzone, MD, MPH; Louis Lam, MD

IMPORTANCE Pulmonary nodules are identified in approximately 1.6 million patients per year in the US and are detected on approximately $30 \%$ of computed tomographic (CT) images of the chest. Optimal treatment of an individual with a pulmonary nodule can lead to early detection of cancer while minimizing testing for a benign nodule.

OBSERVATIONS At least $9 5 \%$ of all pulmonary nodules identified are benign, most often granulomas or intrapulmonary lymph nodes. Smaller nodules are more likely to be benign. Pulmonary nodules are categorized as small solid $( < 8 \mathsf { m m } )$ , larger solid $\scriptstyle ( \geq 8 \mathsf { m m } )$ , and subsolid. Subsolid nodules are divided into ground-glass nodules (no solid component) and part-solid (both ground-glass and solid components). The probability of malignancy is less than $1 \%$ for all nodules smaller than $6 { \mathsf { m m } }$ and $1 \%$ to $2 \%$ for nodules $6 { \mathsf { m m } }$ to $8 { \sf m m }$ . Nodules that are 6 mm to ${ 8 } \mathsf { m m }$ can be followed with a repeat chest CT in 6 to 12 months, depending on the presence of patient risk factors and imaging characteristics associated with lung malignancy, clinical judgment about the probability of malignancy, and patient preferences. The treatment of an individual with a solid pulmonary nodule ${ 8 } \mathsf { m m }$ or larger is based on the estimated probability of malignancy; the presence of patient comorbidities, such as chronic obstructive pulmonary disease and coronary artery disease; and patient preferences. Management options include surveillance imaging, defined as monitoring for nodule growth with chest CT imaging, positron emission tomography–CT imaging, nonsurgical biopsy with bronchoscopy or transthoracic needle biopsy, and surgical resection. Part-solid pulmonary nodules are managed according to the size of the solid component. Larger solid components are associated with a higher risk of malignancy. Ground-glass pulmonary nodules have a probability of malignancy of $10 \%$ to $50 \%$ when they persist beyond 3 months and are larger than $1 0 \mathsf { m m }$ in diameter. A malignant nodule that is entirely ground glass in appearance is typically slow growing. Current bronchoscopy and transthoracic needle biopsy methods yield a sensitivity of $70 \%$ to $90 \%$ for a diagnosis of lung cancer.

CONCLUSIONS AND RELEVANCE Pulmonary nodules are identified in approximately 1.6 million people per year in the US and approximately $30 \%$ of chest CT images. The treatment of an individual with a pulmonary nodule should be guided by the probability that the nodule is malignant, safety of testing, the likelihood that additional testing will be informative, and patient preferences.

Multimedia

CME Quiz at jamacmelookup.com

JAMA. 2022;327(3):264-273. doi:10.1001/jama.2021.24287

Author Affiliations: Respiratory Institute, Cleveland Clinic, Cleveland, Ohio.

Corresponding Author: Peter J. Mazzone, MD, MPH, Respiratory Institute, Cleveland Clinic, 9500 Euclid Ave, A90, Cleveland, OH 44195 (mazzonp@ccf.org).

Section Editor: Mary McGrae McDermott, MD, Deputy Editor.

△ pulmonary nodule is a small radiographic density completely $( < 3 \mathsf { c m } )$ ), focal, distinctnded by lung tissue. Pulmonary nodules are identified in approximately 1.6 million people per year in the US and are detected on approximately $30 \%$ of computed tomographic (CT) images of the chest.1 More than $50 \%$ of patients with a pulmonary nodule have more than 1 nodule.2 Ideal evaluation of an individual with a pulmonary nodule would expedite therapy for a malignant nodule and minimize testing for those with a benign nodule.

This review focuses on evaluation of individuals with a single dominant pulmonary nodule. The term dominant refers to the largest or the most suspicious-appearing nodule. This review does not discuss management of pulmonary nodules in patients with known malignancy, patients with multiple pulmonary nodules without a dominant pulmonary nodule, or patients with a pulmonary mass, defined as a lung opacity with a diameter greater than $3 \mathsf { c m }$ . The management approach to these individuals differs from that of an individual with a dominant pulmonary nodule, and pulmonary masses have a high probability of malignancy. This review describes current evidence regarding the optimal methods to establish the diagnosis of a dominant pulmonary nodule that may be due to primary lung malignancy, metastatic disease, a noninfectious inflammatory process, infection, or scar residual from a prior infection.

This review describes the epidemiology of pulmonary nodules and current evidence-based approaches to treatment of an individual with a pulmonary nodule that is identified incidentally on chest x-ray, chest CT, or during low-dose CT screening (LDCT) for lung cancer.

# Methods

PubMed and Cochrane databases were searched for Englishlanguage articles related to the epidemiology and treatment of adults with pulmonary nodules that were published from January 1, 2011, through September 28, 2021. Search terms included lung nodule(s), pulmonary nodule(s), and any combination, modified by solitary, multiple, screening, screen-detected, and incidental. Results were further categorized by the following terms: guidelines, risk, risk assessment, calculator, model, algorithm, diagnosis, diagnostic techniques, procedures, biopsy, bronchoscopy, surgery, resection, (disease) management, treatment, therapy, tumor board, and clinic. A total of 286 articles were retrieved. Results were supplemented with relevant articles from the references of selected articles and the authors’ files. A total of 51 articles were selected for inclusion, including 9 clinical practice guidelines, 11 clinical trials (6 randomized, 5 nonrandomized), 5 prospective cohort studies, 14 retrospective cohort studies, 5 risk calculator development or validation studies, 3 systematic reviews with meta-analyses, 3 biomarker accuracy studies, and 1 questionnaire study. Articles were selected with the intent of identifying those with the highest-quality study design for each section of the review and relevance to a general medical readership.

# Discussion

# Epidemiology

Approximately $9 5 \%$ of all pulmonary nodules identified on CT scans are benign.1 The prevalence of pulmonary nodules in highrisk populations, such as those who are eligible for LDCT screening (ie, those aged 50-80 years with $\scriptstyle 2 0$ pack-years’ smoking history who have smoked within the past 15 years),3 those with a cancer history, family history of lung cancer, or another significant risk factor (ie, asbestos exposure), has varied, in part based on the size threshold used to define a nodule. In a Veterans Health Administration lung cancer screening implementation study that included any size pulmonary nodule in the definition of a positive finding, 1257 of 2106 screened individuals $( 5 9 . 7 \% )$ ) had a pulmonary nodule.4 In the National Lung Screening Trial, nodules $4 \mathsf { m m }$ or larger were identified in $2 7 . 3 \%$ (7191 of 26 309) of baseline LDCT scans.5 Among 24 604 patients undergoing a second LDCT screening test (12 months after the baseline CT), 644 $( 2 . 6 \% )$ were identified as having a new nodule since the prior screening CT scan.6 In the NELSON trial of 6309 patients undergoing screening for lung cancer, 147 patients $( 2 . 3 \% )$ had a nodule identified during baseline screening that grew at a concerning pace measured 3 months later, defined as a volume doubling time of less than 400 days.7 In 2 studies of screening chest x-rays involving 103 500 participants, a pulmonary nodule was identified in $7 . 8 \%$ to $8 . 9 \%$ of the chest x-rays.8,9 Imaging of the neck, abdomen, and heart can also identify pulmonary nodules. Of 1000 CT angiograms performed as a diagnostic test for pulmonary embolism in an emergency department, 99 $( 9 . 9 \% )$ ) had nodules that required follow-up.10

The incidence of a pulmonary nodule increases with age, from 0.4 per 1000 person-years in people aged 18 to 24 years to 20.3 per 1000 person-years in those aged 85 to 89 years. In part, this increase is explained by the increase in chest CT imaging that occurs with age. The incidence of a pulmonary nodule is slightly higher in women (5.8 per 1000 person-years) than in men (5.2 per 1000 person-years) overall; however, for those older than 70 years, the incidence is higher in men.1 In lung cancer screening trials, the rate of identifying a pulmonary nodule on baseline LDCT was similar in men $( 2 7 . 0 \% )$ ) and women $( 2 7 . 8 \% )$ ).9 In chest x-rays, the rate of identifying a pulmonary nodule was slightly higher in men than women $9 . 6 \% 9 . 8 \%$ vs $8 . 2 \% 8 . 3 \%$ ).8,9 Rates of nodule identification on LDCT also increase with age. For example, in a study of 26 309 people aged 55 to 74 years who received an LDCT, the prevalence of pulmonary nodules was $2 4 . 3 \%$ in those aged 55 to 59 years and $3 4 . 0 \%$ in those aged 70 to 74 years.9 In this study, the prevalence of pulmonary nodules was $2 3 . 2 \%$ in individuals with 30 to 35 pack-year smoking histories and $3 0 . 3 \%$ in those with more than 50 pack-years’ smoking histories.8,9 Although the rate of identification of pulmonary nodules on chest x-ray is much lower than on chest CT scan, similar trends in the prevalence of pulmonary nodules were observed in those screened with chest $\mathsf { X }$ -ray ( $8 . 0 \%$ in those who never smoked, $9 . 5 \%$ in those who previously smoked, $1 1 . 0 \%$ in those who currently smoke).8,9

The frequency of identifying pulmonary nodules is particularly high in individuals undergoing imaging for evaluation of a known extrapulmonary malignancy, reaching $7 5 \%$ (233 of 308) of patients in 1 study.11 Other factors associated with a higher risk of a pulmonary nodule in a cohort of 26 004 individuals undergoing a baseline LDCT included a history of hard-rock mining $( 3 5 . 0 \%$ vs $2 7 . 3 \%$ ; odds ratio [OR], 1.40 $[ 9 5 \%$ CI, 1.04-1.89]), White race $2 8 . 0 \%$ vs $2 0 . 6 \%$ ; OR, 1.39 $[ 9 5 \%$ CI, 1.25-1.55]), residence in an area endemic for Histoplasma such as the Ohio River Valley (OR, 1.30 $[ 9 5 \%$ CI, 1.21-1.40]; calculated absolute rates: $3 2 . 5 \%$ v s $2 6 . 4 \%$ ), farm work (OR, 1.13 $[ 9 5 \%$ CI, 1.03-1.23]; calculated absolute rates: $3 0 . 2 \%$ vs $2 7 . 1 \%$ ), and a history of chronic obstructive pulmonary disease (OR, 1.08 $[ 9 5 \%$ CI, 1.01-1.17], calculated absolute rates: $3 0 . 1 \%$ vs $2 6 . 8 \%$ ).12

# Pulmonary Nodule Evaluation

A focused history may identify recent exposure to an endemic infection such as histoplasmosis or coccidioidomycosis, symptoms related to infection, systemic inflammatory disease or malignancy, and personal histories of malignancy or comorbid conditions that can manifest as a pulmonary nodule.

When evaluating a newly diagnosed pulmonary nodule, it is important to review prior imaging, if available, to determine whether the size and other characteristics of the pulmonary nodule have changed. This may include abdominal imaging if the nodule is at the base of the lungs, head and neck imaging if the nodule is in the upper lung zones, or cardiac imaging. It is not necessary to perform a diagnostic CT of the entire chest if a low-risk pulmonary nodule is first noted on a different type of CT scan. Moreover, a solid nodule that has remained unchanged in size on a chest CT over a period of 2 years or longer is considered benign.

# Downloaded from jamanetwork.com by Central South University user on 12/28/2023

![](images/aefdefef8d58e3de36f030f5c540309e68b5955c68e044e6a1ec19421aa1fad3.jpg)  
Figure. Pulmonary Nodule Examples on Computed Tomography

Panel A shows a calcified pulmonary nodule (blue arrowhead) consistent with benign calcified granulomas. Panel B shows a typical perifissural nodule (blue arrowhead) abutting the fissure (pink arrowhead). Panel C shows a peripheral pulmonary nodule (blue arrowhead) with adjacent satellite nodules (pink arrowheads) consistent with granulomatous process.

# Box 1. Commonly Asked Questions

# Are there any situations in which a pulmonary nodule does not require subsequent imaging or further evaluation?

If a pulmonary nodule has a very low probability of being malignant, further follow-up with imaging is not warranted. Examples include patients with prior imaging showing that the nodule has been stable for 2 years or longer; a nodule that has imaging features confirming a benign diagnosis (eg, dense central calcification, fat density within the nodule); or a solid or a pure ground-glass nodule $< 6 \mathsf { m m }$ in diameter in an individual without any lung cancer risk factors.

Are there scenarios where practice guidelines do not apply? Practice guidelines may not apply to patients for whom the risk of malignancy differs from the general population. For example, patients with a known malignancy or recent history of malignancy; patients with organ transplant or other immunocompromised state; or patients aged $< 3 5$ years. For these individuals, referral to a pulmonologist or to a multidisciplinary pulmonary nodule specialty clinic may be warranted.

When should a primary care physician consider referring a patient with a pulmonary nodule to a specialist? Primary care physicians should refer a patient for specialty evaluation when they are uncomfortable with or uncertain about the most optimal evaluation plan. In addition, primary care physicians should consider referring patients with a large solid pulmonary nodule $\geq 8 - 3 0 \mathsf { m m }$ ) or a subsolid pulmonary nodule due to their higher risk of malignancy.

Imaging features should be carefully reviewed. CT images should be reconstructed in axial, coronal, and sagittal planes to provide the most detailed characterization of nodule features.

Panel D shows a pulmonary hamartoma (blue arrowhead) with areas of intrinsic fat attenuation that appear as black spots on a soft tissue window (pink arrowheads). Panel E shows a feeding and draining vessel of an arteriovenous malformation (blue arrowhead). Panel F shows a ground-glass nodule without a definable solid component (blue arrowhead).

A benign pattern of calcification (eg, dense central [ie, a nodule with a large calcification in the middle vs a small one at the edge], laminated, stippled, or popcorn patterns of calcification; Figure, A) can obviate the need for follow-up imaging. In addition, a perifissural nodule, consisting of a smooth, well-circumscribed nodule adjacent to a lung fissure, most likely represents a lymph node and does not require subsequent monitoring with CT scans (Figure, B).13 Satellite nodules, defined as small solid nodules surrounding a larger nodule, with nearby adenopathy may suggest a granulomatous infection (Figure, C). Fat density within the nodule is suggestive of a hamartoma (Figure, D), and vessels leading into (feeding) and exiting from (draining) the nodule can be seen with an arteriovenous malformation (Figure, E).

Evaluation of an individual with a pulmonary nodule requires knowledge about the factors associated with the probability that the nodule is malignant, the performance characteristics of additional testing, and the advantages and disadvantages of less intensive or more intensive follow-up (Box 1). Recognizing that the probability of malignancy and the yield of available diagnostic tests vary with the size and character of the nodule, nodules are often considered and managed by categorizing them into 1 of 3 groups: small solid nodules, larger solid nodules, and subsolid nodules.

# Small Solid Pulmonary Nodules $( < 8 \mathsf { m m } )$

When incidentally discovered on imaging in individuals without a known history of malignancy, or when detected during LDCT screening, the probability of malignancy is very low. In the National Lung Screening Trial of 26 309 people at high risk for having lung cancer who received an LDCT, pulmonary nodules 4 to $6 \mathsf { m m }$ in diameter accounted for $5 2 . 3 \%$ (3668 of 7019) of all nodules $4 \mathsf { m m }$ or larger and had a $0 . 5 \%$ probability of malignancy, while nodules

Table 1. Society Guidelines for the Management of Pulmonary Nodules   

<table><tr><td>Nodule diameter</td><td>American College of Chest Physicians15a</td><td>Fleischner Society14a</td><td>Lung-RADS16b</td></tr><tr><td rowspan="4">Up to 6 mm</td><td>≤4 mm: Low-risk: patient discussion,</td><td>&lt;6 mm/&lt;100 mm³: Low-risk: No follow-up</td><td rowspan="4">&lt;6 mm at baseline (or new nodule &lt;4 mm on follow-up): return to annual screening (category 2)</td></tr><tr><td>optional follow-up High-risk: follow-up CT scan at12 mo (if stable no further</td><td>High-risk: Optional follow-up CT in 12 mo</td></tr><tr><td>follow-up) &gt;4 to 6 mm: Low-risk: follow-up CT scan</td><td></td></tr><tr><td>at12 mo (if stable, no further follow-up) High-risk: follow-up CT scan at 6-12 mo (if stable,</td><td></td></tr><tr><td rowspan="2">6 to 8 mm</td><td>follow-up at 18-24 mo) &gt;6 to &lt;8 mm: Low-risk: follow-up CT scan at 6-12 mo (if stable,</td><td>6 mm to8 mm/100 mm³ to 250mm³: Low-risk: follow-up CT in</td><td rowspan="2">≥6 mm to &lt;8 mm at baseline (or new nodule 4 mm to &lt;6 mm on follow-up): LDCT in 6 mo (category 3)</td></tr><tr><td>follow-up at 18-24 mo) High-risk: follow-up CT scan 3-6 mo (if stable, then 9-12 mo and 24 mo)</td><td>6-12 mo, then consider follow-up scan at18-24 mo High-risk: follow-up CT in 6-12 mo, then repeat scan in 18-24 mo</td></tr><tr><td rowspan="2">8 mm or greater</td><td>≥8 mm: Assess surgical risk and determine pretest probability of malignancy: Pretest probability&lt;5%: surveillance CT in 3 mo</td><td>d8mm/&gt;250mm³： Low-risk: consider follow-up CT at3mo,PET/CT,ise sampling High-risk: consider</td><td rowspan="2">≥8 mm to&lt;15 mmat baseline (or growing &lt;8 mm or new nodule6mm to&lt;8 mm on follow-up): 3-mo LDCT or PET/CT (category 4A) ≥15 mm (new or growing ≥8 mm): CT,PET/CT,and/or tisue sampling depending on probability of malignancy and comorbidities (category 4B)</td></tr><tr><td>Pretest probability 5%-65%: PET/CT scan to determine continued surveillance, nonsurgical biopsy, or surgical biopsy/resection Pretest probability &gt;65%: referral for surgicalbiopsy or</td><td>follow-up CTat 3 mo, PET/CT,or tissue sampling</td></tr></table>

Abbreviations: CT, computed tomography; LDCT, low-dose CT; PET, positron emission tomography.

a The American College of Chest   
Physicians criteria for low risk   
include individuals of younger age, little or no smoking history, smaller nodule size, regular margins, and location other than upper lobe.   
Criteria for high risk include   
individuals of older age, heavy   
smoking history, larger nodule size, irregular or spiculated margins, and upper lobe locations.   
Intermediate-risk individuals have a combination of high- and low-risk criteria. The Fleischner Society uses the same risk stratification as the American College of Chest   
Physicians.

b Guideline is used for management of screen-detected pulmonary nodules as part of lung cancer screening program. The Lung-RADS guideline categorizes nodules based on their risk of malignancy: category 1 is a CT without any nodules; category 2 nodules have an average probability of malignancy ${ < } 1 \%$ ; category 3 nodules have an average probability of malignancy of $1 \% - 2 \%$ ; category 4A nodules, $5 \mathrm { - } 1 5 \%$ ; and category $4 B > 1 5 \%$ .

$7 \mathsf { m m }$ to $1 0 \mathsf { m m }$ in diameter accounted for $3 0 . 1 \%$ (2115 of 7019) of all nodules $4 \ m \mathsf { m }$ or larger and had a $1 . 7 \%$ probability of malignancy.9 However, these probabilities represented means among all individuals who present with a nodule in these size ranges. The probability of malignancy in an individual with lung cancer risk factors who has a $7 - \mathsf { m m }$ pulmonary nodule with concerning imaging features (ie, irregular or spiculated edges, upper lobe location) may approach $10 \%$ .

$^ { 1 8 } \mathsf { F }$ -fludeoxyglucose–positron emission tomography (FDGPET) imaging, bronchoscopy, and transthoracic needle biopsy are unlikely to help identify malignancy in individuals with small solid pulmonary nodules. Nodules smaller than ${ 8 } \mathsf { m m }$ in diameter are below the spatial resolution of FDG-PET imaging and are difficult to locate during bronchoscopic or transthoracic needle biopsy. For these reasons, individuals with pulmonary nodules smaller than ${ 8 } \mathsf { m m }$ in diameter are usually monitored with serial chest CT imaging. The time interval between CT scans, performed to monitor changes in the nodule that could indicate malignancy, is based on the nodule size and the presence of risk factors for lung cancer. More recently published guidelines recommend longer intervals, such as 6 or 12 months, rather than 3 months, between monitoring scans.14

In summary, available guidelines suggest that a nodule smaller than $6 { \mathsf { m m } }$ should be monitored with a chest CT in 12 months in individuals with lung cancer risk factors such as a history of smoking or a family history of lung cancer. No additional CT imaging is required in those without lung cancer risk factors (Box 1). A nodule between $6 { \mathsf { m m } }$ and ${ 8 } \mathsf { m m }$ should be monitored with a chest CT in 6 months. Flexibility in these time intervals (eg, 3-6 months, 6-12 months) is included in the guidelines to accommodate nodule features other than size, as well as clinician and patient preferences. Low radiation dose techniques are suggested for CT imaging. Details of the guideline recommendations for management of small solid pulmonary nodules can be found in Table 1. 14-16

# Larger Solid Pulmonary Nodules (≥8 to $3 0 \mathsf { m m }$ )

The evaluation of larger solid nodules, $8 { \sf m m }$ to 30 mm in diameter, involves consideration of patient and nodule characteristics, as well as an understanding of the diagnostic accuracy and safety of additional testing. The probability of malignancy in solid nodules of 8 mm to $3 0 \mathsf { m m }$ ranges from very low $( < 1 \% )$ to high $( > 7 0 \% )$ , depending on patient lung cancer risk factors and imaging features such as nodule size, location, edge features (eg, smooth, irregular, lobulated, or spiculated edges), and the presence of calcification. Available tests, such as FDG-PET/CT imaging, bronchoscopy, and transthoracic needle biopsy, have a higher diagnostic yield for nodules 8 mm to $3 0 \mathsf { m m }$ in diameter than for small solid pulmonary nodules. Primary care clinicians should consider referring individuals with a pulmonary nodule of ${ 8 } \mathsf { m m }$ to $3 0 \mathsf { m m }$ in size to a multidisciplinary pulmonary nodule program if available (Box 1).

Risk Prediction | The evaluation of a larger solid pulmonary nodule (ie, $8 { \cdot } 3 0 \mathsf { m m }$ ) should begin with an estimate of the probability that the nodule is malignant. This estimate can be based on an expert

# Downloaded from jamanetwork.com by Central South University user on 12/28/2023

Table 2. Validated Risk Prediction Models for Evaluation of Pulmonary Nodules   

<table><tr><td>Risk prediction model</td><td>Mayo Clinic mode[17</td><td>Herder mode[18</td><td>VA mode[19</td><td>Brock University model2</td><td>Cleveland Clinic mode[20</td></tr><tr><td>Nodule detection</td><td>Incidental nodule on chest radiograph</td><td>Incidental nodule on chest radiograph and PET scan was performed for further evaluation</td><td>Incidental nodule seen on chest radiographic confirmed on CT imaging +/- PET scan</td><td>Nodules detected on LDCT as part of lung cancer screening program</td><td>Incidental nodules referredto biopsy or resection</td></tr><tr><td>% Of nodules that23 were malignant in the cohort used to develop the model</td><td></td><td>57</td><td>54</td><td>5.5</td><td>66.5</td></tr><tr><td>Modelvariables</td><td>Age Smoking history History of extrathoracic malignancy ≥5 y ago Nodule diameter Spiculation Upper lobe</td><td>Mayo Clinic model + FDG-PET uptake</td><td>Age Smoking history Time since quitting smoking Nodule diameter</td><td>Age Sex Family history of lung cancer Emphysema Nodule Size Nodule type Location Nodule count</td><td>Age Smoking history Upper lobe location Solid and irregular/spiculated noduleedges Emphysema FDG-PETavidity History of cancer</td></tr><tr><td>Area under the curve</td><td>location 0.83</td><td>0.88</td><td>0.79</td><td>≥0.94</td><td>other than lung 0.75-0.81 (C-index)</td></tr></table>

Abbreviations: CT, computed tomography; FDG,18F-fludeoxyglucose; LDCT, low-dose CT; PET, positron emission tomography; VA, Veterans Affairs.

clinician’s assessment or may be calculated using a validated pulmonary nodule risk prediction calculator (Table 2). Variables in pulmonary nodule risk calculators include lung cancer risk factors (age, smoking history, personal history of other cancers, family history of lung cancer, presence of chronic obstructive pulmonary disease) and nodule features known to be associated with an increased probability of malignancy (larger size, upper lobe location, partsolid density, irregular or spiculated edges, fewer total pulmonary nodules, increased FDG uptake on PET imaging, or a concerning growth rate such as nodule volume doubling or diameter increasing by $> 2 5 \%$ in 30-400 days).

Several risk calculators have been developed and their accuracies have been externally validated (Table 2).2,17-20 Individual risk calculators are more accurate in populations similar to those in which they were developed. For example, a risk calculator developed in a cohort of people with a pulmonary nodule presenting to a surgical clinic would not be as accurate when used to assess individuals with a pulmonary nodule identified during lung cancer screening. Thus, it is important to use a model that was derived from a population similar to the patient whose nodule is undergoing evaluation. A calculator developed in a screening population can be used to estimate the probability of malignancy in small solid pulmonary nodules as well. Many risk calculators have online tools to assist with their use. The clinical utility of pulmonary nodule risk calculators has been more difficult to confirm than their accuracy. Some studies have shown that the assessments of clinical experts and radiologists are comparable with that of the validated risk calculator scores (ie, area under the curve, 0.70-0.85 compared with 0.72-0.77, respectively, for identifying the presence of lung cancer).21,22

Management Options | In addition to the probability of malignancy, the evaluation of an individual with a larger solid pulmonary nodule is based on the yield of available diagnostic testing, patient comorbidities, and patient preferences. Management options for CTdetected pulmonary nodules include follow-up monitoring with serialCT imaging, furtherevaluationwith FDG-PET imaging, nonsurgical biopsy (bronchoscopy, transthoracic needle biopsy), or surgical resection via a video or robotic-assisted approach. If a new nodule is first identified on a chest x-ray, a chest CT should be performed to better characterize the nodule and assess for lymphadenopathy.

Serial CT imaging is appropriate if a pulmonary nodule has a low probability of malignancy (eg, ${ < } 1 0 \% )$ ), if other management options (FDG-PET imaging, bronchoscopic or transthoracic needle biopsy) are considered unlikely to be informative or are high-risk procedures, or if an informed patient prefers a less aggressive approach. For solid pulmonary nodules ${ 8 } \mathsf { m m }$ to $3 0 \mathsf { m m }$ in size, when surveillance chest CT is the preferred approach, the first surveillance chest CT should be performed 3 months after the initial CT. A meaningful change in nodule size is defined as an increase of $2 \mathsf { m m }$ or more in mean diameter, rounded to the nearest millimeter.23 If the nodule decreases in size, additional monitoring is not required. If the nodule remains stable in size, a chest CT should be performed 6 months later. If the nodule is unchanged on this subsequent imaging, a follow-up chest CT 12 months later would be appropriate. If the nodule is growing at a pace consistent with malignancy (eg, volume doubling time $> 3 0$ days and $\mathtt { < 4 0 0 }$ days), it should be further evaluated without delay (see options below). If the nodule grows at a very slow pace (eg, volume doubling time $\mathord { > } 4 0 0$ days), an indolent malignancy remains possible and a discussion with the patient about the management strategy should occur.

FDG-PET imaging can assist with characterization of an intermediate-risk large solid pulmonary nodule (eg, $10 \% { - } 7 0 \%$ probability of malignancy). FDG-PET imaging provides information about the metabolic activity of the nodule. A pulmonary nodule with high metabolic activity is more likely to be malignant, although there is significant overlap in FDG uptake between malignant and benign (ie, infectious/inflammatory) nodules. An indolent malignancy can have a false-negative result given its lower metabolic activity. A meta-analysis evaluating the discriminative accuracy of FDG-PET imaging for pulmonary nodule evaluation reported a pooled sensitivity of $89 \%$ $9 5 \%$ CI, $8 6 \% - 9 1 \%$ ) and specificity of $7 5 \%$ $9 5 \%$ CI, $7 1 \% - 7 9 \%$ ).24 There was significant heterogeneity of the specificity, with lower specificity values identified in higherquality studies and a $1 6 \%$ lower specificity in areas with endemic fungal infections such as the Ohio River Valley (histoplasmosis) and Southwestern US (coccidioidomycosis).24 FDG-PET imaging may also identify regional and distant spread of lung cancer.

When imaging findings suggest an intermediate probability of malignancy (eg, $1 0 \% . 7 0 \%$ ), a nonsurgical biopsy, such as a CT-guided transthoracic needle biopsy or guided bronchoscopy, may be offered. The choice between a CT-guided transthoracic needle biopsy and a guided bronchoscopy procedure is based on several factors, including location of the nodule, available clinical expertise, and patient comorbidities and values. A pulmonary nodule located in the periphery of the lung field is more likely to be accessible by transthoracic needle biopsy, while a pulmonary nodule located along the path of an airway may be more easily approached by bronchoscopy. In a meta-analysis, transthoracic needle biopsy had a higher pooled diagnostic yield $9 3 \%$ $[ 9 5 \% \mathsf { C l }$ , $9 0 \% 9 6 \%$ ) than bronchoscopy $7 5 \%$ $9 5 \%$ CI, $6 9 \% 8 0 \% ]$ ), but was associated with an increased risk for pneumothorax $( 2 6 \% )$ and hemorrhage $( 1 6 \% )$ .25 Advances in technologies that augment the ability to guide the bronchoscope to a peripheral nodule, confirm the location of the nodule, and provide representative samples of the nodule, including electromagnetic navigation,26 radial endobronchial ultrasound, ultrathin bronchoscopes,27 and roboticassisted bronchoscopy,28 have substantially improved diagnostic yields of guided bronchoscopy while maintaining low complication rates. In a meta-analysis, the pooled sensitivity for malignancy of electromagnetic navigation bronchoscopy was $7 7 \%$ ( $9 5 \%$ CI, $7 2 \%$ - $8 2 \%$ with a $2 . 0 \%$ risk of pneumothorax $9 5 \%$ CI, $1 . 0 \% { - 3 . 0 \% }$ ) and $0 . 8 \%$ risk of major bleeding $9 5 \%$ CI, $0 . 5 \%$ -1.1%).29 An added value of performing bronchoscopy is the ability to perform endobronchial ultrasound-guided biopsy of the hila and mediastinum if indicated for staging.

When the probability of malignancy is high (eg, ${ > } 7 0 \%$ ), proceeding to surgical resection via a video or robotic-assisted approach is recommended in individuals without life-limiting comorbidities, such as severe emphysema or severe heart failure, and who meet criteria of cardiopulmonary fitness, such as predicted postoperative forced expiratory volume in 1 second and diffusing capacity greater than $60 \%$ predicted, suggesting a low risk associated with surgical resection.30 Ideally, a surgical wedge resection to confirm the presence of cancer, obtained during an intraoperative frozen section, can be followed by definitive treatment (eg, lobectomy or segmentectomy) during the same operation. For individuals with lifelimiting comorbidities and for those at high risk for complications from surgical resection, other potential nonsurgical options may include nonsurgical biopsy (transthoracic needle biopsy and bronchoscopy), stereotactic radiotherapy, or otherablative therapies. Feasibility of the biopsy, patient fitness, and patient preferences help inform this decision-making process.

Individualizing Care | In general, nodules can be classified into 1 of 3 categories of risk of malignancy and managed accordingly: those with a low risk (eg, ${ < } 1 0 \%$ ) can be monitored with imaging; those with an intermediate risk (eg, $10 \% { - } 7 0 \%$ risk) should typically undergo additional diagnostic testing, and those with a high risk (eg, $5 7 0 \%$ risk) should proceed directly to surgery. These thresholds refer to the management of the population of patients with a pulmonary nodule and need to be considered in the context of other factors for individual patients. Two nodules with an identical

Box 2. Individualized Pulmonary Nodule Management Based on Probability of Malignancy14-16,31-33a

${ < } 1 \%$ No additional testing or monitoring needed.

$1 \% - 5 \%$ Monitoring with chest computed tomography (CT) per guideline recommendations, based on nodule size.

$5 \% - 3 0 \%$ Monitor with chest CT in 3 months or pursue additional testing with positron emission tomography (PET)/CT imaging and/or a nonsurgical biopsy. Factors that favor monitoring include severe comorbidities, limited life expectancy, difficult nodule location, patient favors conservative management, slow growth rate, and low metabolic activity.

$3 0 \% 6 5 \%$ Additional testing with PET/CT imaging and/or a nonsurgical biopsy. Factors that favor guided bronchoscopy vs transthoracic needle biopsy include airway leading to the nodule, severe emphysema, available local expertise, and need to invasively stage the mediastinum.

$6 5 \% { - } 9 0 \%$ Additional testing with PET/CT imaging and/or a nonsurgical biopsy or proceed directly to thoracoscopic surgical resection. Factors that favor surgical resection include low-yield nonsurgical biopsy location, excellent cardiopulmonary fitness, and patient favors aggressive management.

${ \tt> } 9 0 \%$ Thoracoscopic surgical resection or stereotactic radiotherapy based on patient comorbidities and values.

a Probability of malignancy is estimated based on clinical experience or a validated risk prediction calculator.

probability of malignancy may be managed differently. Factors that influence clinical decisions include the anticipated diagnostic yield of a nonsurgical biopsy, patient comorbidities that influence the safety of a procedure, the likelihood of benefit from establishing a diagnosis (life expectancy, nodule growth rate, metabolic activity), and patient values (Box 2). It is important to note that after completion of all nonsurgical testing (ie, FDG/PET imaging, nonsurgical biopsy), in some patients the probability of malignancy may be higher than accepted thresholds for monitoring with imaging and lower than accepted thresholds for surgical resection. In this situation, the managing clinician and patient should discuss the tradeoffs of monitoring vs surgical resection to determine the most appropriate next step for that individual. It is also important to recognize that some cancers may grow slowly on serial imaging, providing the opportunity for the clinician and patient to discuss the preferred timing of treatment.

# Subsolid Pulmonary Nodules

Subsolid pulmonary nodules consist of pure ground-glass (Figure, F) and part-solid pulmonary nodules. Ground glass refers to a density in which the lung architecture (such as blood vessels) is not obscured by the nodule. Part-solid refers to a nodule that has both ground-glass and solid components. Malignant subsolid pulmonary nodules grow at a slower pace than malignant solid nodules and are typically adenocarcinomas (adenocarcinoma in situ or minimally invasive adenocarcinoma in the ground-glass portion and invasive adenocarcinoma in the solid portion). In 1 series of 439 pure ground-glass nodules that were smaller than 6 mm in diameter and followed up forat least 5years (median imaging follow-up,6.0years), 45 $( 1 0 . 3 \% )$ grew and 4 $( 0 . 9 \% )$ ) developed into adenocarcinomas.34 In another series of 226 patients with subsolid pulmonary nodules,

# Downloaded from jamanetwork.com by Central South University user on 12/28/2023

Table 3. Society Guidelines for the Management of Subsolid Pulmonary Nodules   

<table><tr><td>American College of Chest Physicians15</td><td>Fleischner Society14 &lt;6 mm/&lt;100 mm³:</td><td>Lung-RADS16a Ground glass nodule</td></tr><tr><td>≤5 mm: no follow-up</td><td>Ground-glass nodule: no routine follow-up Part-solid: no routine follow-up</td><td>&lt;30 mm at baseline (or any size unchanged): return to annual screening (category 2) Part-solid nodule &lt;6 mm at baseline: return to annual screening (category 2) Part-solid nodule &lt;6 mm (new): follow-up CT scan at6 mo (category 3)</td></tr><tr><td>&gt;5 mm: Ground-glass nodule: follow-up CT scan at 12 mo then annual through 3y Part-solid nodule: ≤8 mm solid component: follow-up CT scanat 3,12,and 24 mo then annual until 5 y</td><td>≥6 mm/&gt;100 mm³: Ground-glass nodule: follow-up CT scan 6-12 mo then every 2-5y Part-solid nodule: follow-up CT scan 3-6 mo thenannually for5y</td><td>Ground glass nodule ≥30 mm at baseline or new on follow-up: follow-up 6-mo CT (category 3) Part-solid nodule: Solid component &lt;6 mm: follow-up CT at 6 mo (category 3) Solid component ≥6 to &lt;8 mm or new or</td></tr></table>

Abbreviations: CT, computed tomography; PET, positron emission tomography. a Guideline is used for management of screen-detected pulmonary nodules as part of lung cancer screening program.

invasive cancer was identified in $4 . 1 \%$ (3 of 74) of resected pure ground-glass malignant nodules (median diameter at time of detection, $1 0 \mathsf { m m }$ ), $7 0 . 0 \%$ (14 of 20) with a solid component greater than $2 5 \%$ of the total nodule size, and $4 5 . 5 \%$ (10 of 22) of those with growth in the solid component.35 A summary of 24 case series that included 704 patients reported that the 5-year lung cancer– specific survival rate was $100 \%$ for malignant pure ground-glass nodules with a mean tumor size of $7 . 9 \mathsf { m m }$ to $1 6 . 6 \mathsf { m m }$ .36

Malignant subsolid pulmonary nodules are relatively slow growing compared with malignant solid nodules. In the series described above of 226 patients with subsolid pulmonary nodules, the solid component of a malignant part-solid nodule grew in $100 \%$ (17 of 17) of nodules within the first 3 years of monitoring, and in $8 6 . 4 \%$ (19 of 22) of malignant pure ground-glass nodules, but none of these cancers spread beyond the nodule during this follow-up period.35 The metabolic activity of a malignant subsolid pulmonary nodule is relatively low (positive FDG-PET scan in $6 0 \% ) ^ { 3 7 }$ and the yield of transthoracic needle biopsies is also relatively low $( 5 1 . 2 \% )$ .37,38 These findings suggest that longer periods of imaging surveillance may be appropriate when following up patients with pure ground-glass nodules, particularly in people with advanced age or with comorbid conditions whose life expectancy is lower than in people who are younger or without comorbid conditions.

In summary, current guidelines suggest a pure ground-glass nodule smaller than $6 { \mathsf { m m } }$ in diameter does not require additional testing or monitoring, but patients and clinicians may decide to perform additional testing or monitoring in selected situations. A ground-glass nodule $6 { \mathsf { m m } }$ or larger can be followed with a chest CT in 6 to 12 months followed by every 2 years for 5 years if it remains stable. The management of a part-solid nodule should be based on the size of the solid component. Surveillance with a chest CT should occur in 6 months if the solid component is smaller than $6 \mathsf { m m }$ or in 3 months if the solid component is $6 \mathsf { m m }$ to ${ 8 } \mathsf { m m }$ . Management of a part-solid nodule in which the solid component is ${ 8 } \mathsf { m m }$ or larger should follow the recommended guidance for large solid nodules.16,17 When monitoring a subsolid pulmonary nodule, the development or growth of a solid component of the nodule is a concerning finding that should lead to more frequent surveillance imaging, nonsurgical biopsy, or surgical resection based on the size of the solid component of the nodule. Growth of the ground-glass component alone does not suggest a malignancy has become invasive and thus does not require more intensive or invasive management. FDG-PET imaging is not useful for evaluating the probability of malignancy unless a solid component of at least ${ 8 } \mathsf { m m }$ is present. Minimally invasive sublobar resection may be considered without biopsy when the size of the solid component of a subsolid lung nodule is growing and is $8 { \sf m m }$ or larger (Table 3 and Box 1).14-16

# Guidelines

Several societies have developed guidelines to assist with the evaluation of an individual with a pulmonary nodule.14-16,31-33 These guidelines vary in their scope and focus, and some are specific to certain geographic regions and health systems.32,33 Some of these guidelines focus on management of a small incidentally detected pulmonary nodule, others focus on management of an LDCT screen-detected pulmonary nodule, and some focus on both types of nodules. However, all the guidelines are organized based on an estimate of the probability that a pulmonary nodule is malignant, knowledge of the risk of malignancy in nodules of different densities, and workup for further assessment of the nodule. Differences in guideline recommendations include the use of different thresholds for the probability of malignancy to provide management recommendations (eg, $< 5 \%$ , $10 \%$ , or $1 5 \%$ probability for monitoring for nodule growth, $5 \% - 1 5 \%$ to $6 5 \% - 7 0 \%$ for additional nonsurgical evaluation, and ${ > } 6 5 \%$ or ${ > } 7 0 \%$ for surgical resection), the frequency and duration of image-based monitoring, the preferred risk calculators for identifying likelihood of malignancy, and whether volumetric imaging with growth rate calculation is recommended.

Guideline recommendations have changed over time, based on a better understanding of probability of malignancy and growth patterns of malignant pulmonary nodules. Changes have included using a higher threshold for probability of malignancy, compared with past guidelines, for use of imaging to monitor growth of a nodule (eg, ${ < } 1 5 \%$ probability currently compared with $1 5 \%$ probability in the past), monitoring less frequently and for shorter durations, and allowing more flexibility in frequency of diagnostic testing, to accommodate consideration of patient risk factors, comorbidities, and values. These guidelines refer to an incidentally or screendetected pulmonary nodule and not a pulmonary nodule in an individual with a known malignancy for whom metastatic disease is a concern (Box 1). Pulmonary nodule guideline recommendations are summarized in Table 1 and Table 3.

Compliance of clinicians with guideline recommendations and patients’ actual follow-up in practice may be suboptimal. In 1 study of 197 patients with pulmonary nodules, 88 $( 4 4 . 7 \% )$ received care inconsistent with guidelines (eg, next surveillance imaging prior to or after the interval recommended in the guidelines, a nonsurgical biopsy instead of surveillance imaging).39 Features leading to noncompliance include inappropriate radiologist guidance ( $6 5 . 6 \%$ v s $1 0 . 8 \%$ ; overevaluation relative risk [RR], 4.6 $[ 9 5 \%$ CI, 2.3-9.2]; underevaluation RR, 4.3 $[ 9 5 \%$ CI, 2.7-6.8]), receiving care at more than 1 facility (RR, 2.0 $[ 9 5 \%$ CI, 1.5-2.7]), and nodule detection during an inpatient stay or preoperative visit (RR, 1.6 $[ 9 5 \%$ C I , 1.1-2.5]).39 Features associated with compliance with following guideline management recommendations by clinicians and compliance with care recommendations by patients include patient distress $6 4 . 4 \%$ vs $5 7 . 4 \%$ ),40 point-of-care reference materials provided in the emergency department $8 0 . 2 \%$ vs $6 7 . 5 \%$ ),41 clinical decision support tools at workstations $6 5 . 2 \%$ vs $4 9 . 6 \%$ ),42 guideline templates added to radiology reports $4 5 \%$ vs $3 1 \%$ ),43 and high-quality communication (OR, 3.7 $[ 9 5 \%$ CI, 1.3-10.6]).40

# System of Care

In practice, primary care clinicians must counsel patients about the evaluation and diagnostic testing of pulmonary nodules and monitor timing of follow-up diagnostic testing.

Multidisciplinary pulmonary nodule specialty clinics are available in some regions to assist in the treatment of patients with pulmonary nodules. These clinics, comprised of a multidisciplinary team of nodule management experts (eg, pulmonologists, thoracic surgeons, radiologists), identify patients with pulmonary nodules by flagging radiology reports (either manually or through computational linguistics) when a pulmonary nodule is identified on imaging. Clinicians at these clinics communicate directly with patients to inform them of the results, use guideline-based pulmonary nodule management algorithms and health management systems to ensure adherence to appropriate follow-up testing, and provide automated patient reminders. In a series of 113 patients, care followed guideline recommendations in 76 patients $( 6 7 . 2 \% )$ ), with the highest rates ( $8 8 \%$ concordant) observed in those with malignant nodules.44 In this setting, among 5057 individuals in which 1863 $( 3 7 \% )$ received less intensive evaluation than recommended in guidelines, fewer procedure-related adverse events (risk difference, $- 5 . 9 \%$ ), lower radiation exposure $( - 9 . 5 \mathsf { m } \mathsf { S } \mathsf { v } )$ ), and lower expenditures ( $- \$ 10$ 916)were noted,withoutaffecting the stage of cancer at diagnosis (risk difference, $4 . 6 \%$ ).45 These results may suggest that individualizing care in a multidisciplinary pulmonary nodule clinic could yield favorable outcomes.

# Shared Decision-making

In a study of 121 patients with pulmonary nodules, psychological distress about the presence of a pulmonary nodule was reported by 69 patients $( 5 7 . 0 \% )$ ), with $2 5 \%$ reporting continued distress 2 years after a pulmonary nodule was diagnosed.46 Fifty-five patients $( 4 5 . 5 \% )$ ) estimated the risk of malignancy associated with their pulmonary

# ARTICLE INFORMATION

Accepted for Publication: December 19, 2021.

Author Contributions: Dr Mazzone had full access to all of the data in the study and takes responsibility for the integrity of the data and the accuracy of the data analysis.

nodule to be at least $30 \%$ when the calculated average risk was $10 \%$ .46 High-quality communication from clinicians has been associated with less patient distress. No distress after a pulmonary nodule diagnosis was reported in $6 0 . 3 \%$ of patients who received highquality communication compared with $4 0 . 7 \%$ inthosewhoreceived low-quality communication.47 In 316 clinician encounters regarding management of pulmonary nodules in which decision-making occurred, patients preferred to have an active role in the management of their pulmonary nodule in 313 $( 9 8 \% )$ of the encounters. However, only one-half of clinicians reported engaging in shared decision-making with patients diagnosed with a pulmonary nodule.48 Clinicians with more years of experience and those who reported feelingmorecomfortableevaluatinga pulmonary nodule used shared decision-making more often.48

# Future Directions

Large imaging data sets have supported the application of artificial intelligence to identify pulmonary nodules most likely to be malignant. A convolutional neural network trained on more than 15 000 images from the National Lung Screening Trial showed improved classification over available risk prediction models when externally validated (area under the curve, 0.84-0.92 vs 0.78-0.82).49 Several molecular biomarkers have been developed to improve pulmonary nodule risk prediction. Some of these biomarkers, present in the blood, airway epithelium, and breath, evaluate changes in circulating tumor DNA, mRNA expression, proteins, autoantibodies, or metabolites, and are currently undergoing assessment for clinical utility.50,51 Multidisciplinary programs of care for individuals with a pulmonary nodule, described above, are increasing in number. Population management tools, which may include decision support tools and may help people adhere to recommended follow-up diagnostic testing, are also increasingly available. These programs may improve clinician adherence with guideline recommendations, patient adherence with recommended management, communication, and patient-related outcomes.

# Limitations

This review has several limitations. First, for some covered topics, high-quality data were not available. Second, some relevant articles may have been missed. Third, a formal quality assessment of included articles was not performed.

# Conclusions

Pulmonary nodules are identified in approximately 1.6 million people per year in the US and approximately $30 \%$ of chest CT images. The treatment of an individual with a pulmonary nodule should be guided by the probability that the nodule is malignant, safety of testing, the likelihood that additional testing will be informative, and patient preferences.

Administrative, technical, or material support: Both authors.   
Supervision: Mazzone.

Conflict of Interest Disclosures: Dr Mazzone reported receiving grants from the Patient-Centered Outcomes Research Institute,

# Downloaded from jamanetwork.com by Central South University user on 12/28/2023

Biodesix, DELFI, Exact Sciences, MagArray, Nucleix, PrognomiQ, Tencent, and Veracyte paid to his institution outside the submitted work. No other disclosures were reported.

Submissions: We encourage authors to submit papers for consideration as a Review. Please contact Mary McGrae McDermott, MD, at mdm608@northwestern.edu.

# REFERENCES

1. Gould MK, Tang T, Liu I-LA, et al. Recent trends in the identification of incidental pulmonary nodules. Am J Respir Crit Care Med. 2015;192(10):1208-1214. doi:10.1164/rccm.201505-0990OC

2. McWilliams A, Tammemagi MC, Mayo JR, et al. Probability of cancer in pulmonary nodules detected on first screening CT. N Engl J Med. 2013; 369(10):910-919. doi:10.1056/NEJMoa1214726

3. Jonas DE, Reuland DS, Reddy SM, et al. Screening for lung cancer with low-dose computed tomography: updated evidence report and systematic review for the US Preventive Services Task Force. JAMA. 2021;325(10):971-987. doi:10. 1001/jama.2021.0377

4. Kinsinger LS, Anderson C, Kim J, et al. Implementation of lung cancer screening in the Veterans Health Administration. JAMA Intern Med. 2017;177(3):399-406. doi:10.1001/jamainternmed. 2016.9022

5. Aberle DR, Adams AM, Berg CD, et al; National Lung Screening Trial Research Team. Reduced lung-cancer mortality with low-dose computed tomographic screening. N Engl J Med. 2011;365(5): 395-409. doi:10.1056/NEJMoa1102873

6. Pinsky PF, Gierada DS, Nath PH, Munden R. Lung cancer risk associated with new solid nodules in the National Lung Screening Trial. AJR Am J Roentgenol. 2017;209(5):1009-1014. doi:10.2214/AJR.17.18252

7. de Koning HJ, van der Aalst CM, de Jong PA, et al. Reduced lung-cancer mortality with volume CT screening in a randomized trial. N Engl J Med. 2020;382(6):503-513. doi:10.1056/NEJMoa1911793

8. Oken MM, Marcus PM, Hu P, et al; PLCO Project Team. Baseline chest radiograph for lung cancer detection in the randomized Prostate, Lung, Colorectal and Ovarian Cancer Screening Trial. J Natl Cancer Inst. 2005;97(24):1832-1839. doi:10. 1093/jnci/dji430

9. Church TR, Black WC, Aberle DR, et al; National Lung Screening Trial Research Team. Results of initial low-dose computed tomographic screening for lung cancer. N Engl J Med. 2013;368(21):1980- 1991. doi:10.1056/NEJMoa1209120

10. Blagev DP, Lloyd JF, Conner K, et al. Follow-up of incidental pulmonary nodules and the radiology report. J Am Coll Radiol. 2014;11(4):378-383. doi:10. 1016/j.jacr.2013.08.003

11. Hanamiya M, Aoki T, Yamashita Y, Kawanami S, Korogi Y. Frequency and significance of pulmonary nodules on thin-section CT in patients with extrapulmonary malignant neoplasms. Eur J Radiol. 2012;81(1):152-157. doi:10.1016/j.ejrad.2010.08.013

12. Balekian AA, Tanner NT, Fisher JM, Silvestri GA, Gould MK. Factors associated with a positive baseline screening exam result in the National Lung Screening Trial. Ann Am Thorac Soc. 2016;13(9): 1568-1574. doi:10.1513/AnnalsATS.201602-091OC

13. Han D, Heuvelmans MA, van der Aalst CM, et al. New fissure-attached nodules in lung cancer

screening: a brief report from the NELSON Study. J Thorac Oncol. 2020;15(1):125-129. doi:10.1016/j. jtho.2019.09.193

14. MacMahon H, Naidich DP, Goo JM, et al. Guidelines for management of incidental pulmonary nodules detected on CT images: from the Fleischner Society 2017. Radiology. 2017;284(1): 228-243. doi:10.1148/radiol.2017161659

15. Gould MK, Donington J, Lynch WR, et al. Evaluation of individuals with pulmonary nodules: when is it lung cancer? diagnosis and management of lung cancer, 3rd ed: American College of Chest Physicians evidence-based clinical practice guidelines. Chest. 2013;143(5)(suppl):e93S-e120S. doi:10.1378/chest.12-2351

16. American College of Radiology Committee on Lung-RADS. Lung-RADS Assessment Categories Version 1.1. Published 2019. Accessed September 15, 2021. https://www.acr.org/-/media/ACR/Files/ RADS/Lung-RADS/ LungRADSAssessmentCategoriesv1-1.pdf

17. Swensen SJ, Silverstein MD, Ilstrup DM, Schleck CD, Edell ES. The probability of malignancy in solitary pulmonary nodules: application to small radiologically indeterminate nodules. Arch Intern Med. 1997;157(8):849-855. doi:10.1001/archinte.1997. 00440290031002

18. Herder GJ, van Tinteren H, Golding RP, et al. Clinical prediction model to characterize pulmonary nodules: validation and added value of 18F-fluorodeoxyglucose positron emission tomography. Chest. 2005;128(4):2490-2496. doi: 10.1378/chest.128.4.2490

19. Gould MK, Ananth L, Barnett PG; Veterans Affairs SNAP Cooperative Study Group. A clinical model to estimate the pretest probability of lung cancer in patients with solitary pulmonary nodules. Chest. 2007;131(2):383-388. doi:10.1378/chest.06- 1261

20. Reid M, Choi HK, Han X, et al. Development of a risk prediction model to estimate the probability of malignancy in pulmonary nodules being considered for biopsy. Chest. 2019;156(2):367-375. doi:10.1016/j.chest.2019.01.038

21. MacMahon H, Li F, Jiang Y, Armato SG III. Accuracy of the Vancouver Lung Cancer Risk Prediction Model compared with that of radiologists. Chest. 2019;156(1):112-119. doi:10.1016/ j.chest.2019.04.002

22. Balekian AA, Silvestri GA, Simkovich SM, et al. Accuracy of clinicians and models for estimating the probability that a pulmonary nodule is malignant. Ann Am Thorac Soc. 2013;10(6):629-635. doi:10. 1513/AnnalsATS.201305-107OC

23. Bankier AA, MacMahon H, Goo JM, Rubin GD, Schaefer-Prokop CM, Naidich DP. Recommendations for measuring pulmonary nodules at CT: a statement from the Fleischner Society. Radiology. 2017;285(2):584-600. doi:10. 1148/radiol.2017162894

24. Deppen SA, Blume JD, Kensinger CD, et al. Accuracy of FDG-PET to diagnose lung cancer in areas with infectious lung disease: a meta-analysis. JAMA. 2014;312(12):1227-1236. doi:10.1001/jama. 2014.11488

25. Han Y, Kim HJ, Kong KA, et al. Diagnosis of small pulmonary lesions by transbronchial lung biopsy with radial endobronchial ultrasound and virtual bronchoscopic navigation versus CT-guided transthoracic needle biopsy: a systematic review and meta-analysis. PLoS One. 2018;13(1):e0191590. doi:10.1371/journal.pone.0191590

26. Folch EE, Pritchett MA, Nead MA, et al; NAVIGATE Study Investigators. Electromagnetic navigation bronchoscopy for peripheral pulmonary lesions: one-year results of the prospective, multicenter NAVIGATE Study. J Thorac Oncol. 2019; 14(3):445-458. doi:10.1016/j.jtho.2018.11.013

27. Oki M, Saka H, Ando M, et al. Ultrathin bronchoscopy with multimodal devices for peripheral pulmonary lesions: a randomized trial. Am J Respir Crit Care Med. 2015;192(4):468-476. doi:10.1164/rccm.201502-0205OC

28. Chen AC, Pastis NJJ Jr, Mahajan AK, et al. Robotic bronchoscopy for peripheral pulmonary lesions: a multicenter pilot and feasibility study (BENEFIT). Chest. 2021;159(2):845-852. doi:10. 1016/j.chest.2020.08.2047

29. Folch EE, Labarca G, Ospina-Delgado D, et al. Sensitivity and safety of electromagnetic navigation bronchoscopy for lung cancer diagnosis: systematic review and meta-analysis. Chest. 2020;158(4):1753- 1769. doi:10.1016/j.chest.2020.05.534

30. Brunelli A, Kim AW, Berger KI, Addrizzo-Harris DJ. Physiologic evaluation of the patient with lung cancer being considered for resectional surgery: diagnosis and management of lung cancer, 3rd ed: American College of Chest Physicians evidence-based clinical practice guidelines. Chest. 2013;143(5)(suppl):e166S-e190S. doi:10.1378/chest. 12-2395

31. Callister MEJ, Baldwin DR, Akram AR, et al; British Thoracic Society Pulmonary Nodule Guideline Development Group; British Thoracic Society Standards of Care Committee. British Thoracic Society guidelines for the investigation and management of pulmonary nodules. Thorax. 2015;70(suppl 2):ii1-ii54. doi:10.1136/thoraxjnl-2015- 207168

32. Lam S, Bryant H, Donahoe L, et al. Management of screen-detected lung nodules: a Canadian partnership against cancer guidance document. Can J Respir Crit Care Sleep Med. 2020;4 (4):236-265. doi:10.1080/24745332.2020.1819175

33. Bai C, Choi C-M, Chu CM, et al. Evaluation of pulmonary nodules: clinical practice consensus guidelines for Asia. Chest. 2016;150(4):877-893. doi:10.1016/j.chest.2016.02.650

34. Kakinuma R, Muramatsu Y, Kusumoto M, et al. Solitary pure ground-glass nodules 5 mm or smaller: frequency of growth. Radiology. 2015;276(3):873- 882. doi:10.1148/radiol.2015141071

35. Sawada S, Yamashita N, Sugimoto R, Ueno T, Yamashita M. Long-term outcomes of patients with ground-glass opacities detected using CT scanning. Chest. 2017;151(2):308-315. doi:10.1016/j.chest.2016. 07.007

36. Yip R, Wolf A, Tam K, et al. Outcomes of lung cancers manifesting as nonsolid nodules. Lung Cancer. 2016;97:35-42. doi:10.1016/j.lungcan.2016. 04.005

37. Heyneman LE, Patz EF. PET imaging in patients with bronchioloalveolar cell carcinoma. Lung Cancer. 2002;38(3):261-266. doi:10.1016/S0169-5002(02) 00221-0

38. Shimizu K, Ikeda N, Tsuboi M, Hirano T, Kato H. Percutaneous CT-guided fine needle aspiration for lung cancer smaller than 2 cm and revealed by

ground-glass opacity at CT. Lung Cancer. 2006;51   
(2):173-179. doi:10.1016/j.lungcan.2005.10.019

39. Wiener RS, Gould MK, Slatore CG, Fincke BG, Schwartz LM, Woloshin S. Resource use and guideline concordance in evaluation of pulmonary nodules for cancer: too much and too little care. JAMA Intern Med. 2014;174(6):871-880. doi:10. 1001/jamainternmed.2014.561

40. Moseson EM, Wiener RS, Golden SE, et al. Patient and clinician characteristics associated with adherence. a cohort study of veterans with incidental pulmonary nodules. Ann Am Thorac Soc. 2016;13(5):651-659. doi:10.1513/AnnalsATS.201511- 745OC

41. Zygmont ME, Shekhani H, Kerchberger JM, Johnson J-O, Hanna TN. Point-of-care reference materials increase practice compliance with societal guidelines for incidental findings in emergency imaging. J Am Coll Radiol. 2016;13(12, pt A):1494- 1500. doi:10.1016/j.jacr.2016.07.032

42. Lu MT, Rosman DA, Wu CC, et al. Radiologist point-of-care clinical decision support and adherence to guidelines for incidental lung nodules. J Am Coll Radiol. 2016;13(2):156-162. doi:10.1016/j. jacr.2015.09.029

43. McDonald JS, Koo CW, White D, Hartman TE, Bender CE, Sykes AG. Addition of the Fleischner Society guidelines to chest CT examination interpretive reports improves adherence to recommended follow-up care for incidental pulmonary nodules. Acad Radiol. 2017;24(3):337-344. doi:10.1016/j.acra.2016.08.026

44. Verdial FC, Madtes DK, Cheng G-S, et al. Multidisciplinary team-based management of incidentally detected lung nodules. Chest. 2020;157 (4):985-993. doi:10.1016/j.chest.2019.11.032

45. Farjah F, Monsell SE, Gould MK, et al. Association of the intensity of diagnostic evaluation with outcomes in incidentally detected lung nodules. JAMA Intern Med. 2021;181(4):480-489. doi:10.1001/jamainternmed.2020.8250

46. Slatore CG, Wiener RS, Golden SE, Au DH, Ganzini L. Longitudinal assessment of distress among veterans with incidental pulmonary nodules. Ann Am Thorac Soc. 2016;13(11):1983-1991. doi:10.1513/AnnalsATS.201607-555OC

47. Slatore CG, Golden SE, Ganzini L, Wiener RS, Au DH. Distress and patient-centered communication among veterans with incidental (not screen-detected) pulmonary nodules: a cohort study. Ann Am Thorac Soc. 2015;12(2):184-192. doi: 10.1513/AnnalsATS.201406-283OC

48. Iaccarino JM, Simmons J, Gould MK, et al. Clinical equipoise and shared decision-making in pulmonary nodule management: a survey of American Thoracic Society Clinicians. Ann Am Thorac Soc. 2017;14(6):968-975. doi:10.1513/ AnnalsATS.201609-727OC

49. Massion PP, Antic S, Ather S, et al. Assessing the accuracy of a deep learning method to risk stratify indeterminate pulmonary nodules. Am J Respir Crit Care Med. 2020;202(2):241-249. doi:10. 1164/rccm.201903-0505OC

50. Lee HJ, Mazzone P, Feller-Kopman D, et al; Percepta Registry Investigators. Impact of the Percepta Genomic Classifier on clinical management decisions in a multicenter prospective study. Chest. 2021;159(1):401-412. doi:10.1016/j. chest.2020.07.067

51. Silvestri GA, Tanner NT, Kearney P, et al; PANOPTIC Trial Team. Assessment of plasma proteomics biomarker’s ability to distinguish benign from malignant lung nodules: results of the PANOPTIC (Pulmonary Nodule Plasma Proteomic Classifier) Trial. Chest. 2018;154(3):491-500. doi:10. 1016/j.chest.2018.02.012

# Downloaded from jamanetwork.com by Central South University user on 12/28/2023