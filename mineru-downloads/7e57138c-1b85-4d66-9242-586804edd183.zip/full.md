# Acute Respiratory Distress Syndrome 2022 1 Acute respiratory distress syndrome: causes, pathophysiology, and phenotypes

Lieuwe D J Bos, Lorraine B Ware

Acute respiratory distress syndrome (ARDS) is a common clinical syndrome of acute respiratory failure as a result of diffuse lung inflammation and oedema. ARDS can be precipitated by a variety of causes. The pathophysiology of ARDS is complex and involves the activation and dysregulation of multiple overlapping and interacting pathways of injury, inflammation, and coagulation, both in the lung and systemically. Mechanical ventilation can contribute to a cycle of lung injury and inflammation. Resolution of inflammation is a coordinated process that requires downregulation of proinflammatory pathways and upregulation of anti-inflammatory pathways. The heterogeneity of the clinical syndrome, along with its biology, physiology, and radiology, has increasingly been recognised and incorporated into identification of phenotypes. A precision-medicine approach that improves the identification of more homogeneous ARDS phenotypes should lead to an improved understanding of its pathophysiological mechanisms and how they differ from patient to patient.

Lancet 2022; 400: 1145–56

Published Online September 4, 2022 https://doi.org/10.1016/ S0140-6736(22)01485-4

This is the first in a Series of three papers about acute respiratory distress syndrome (paper 3 appears in The Lancet Respiratory Medicine). All papers in the Series are available at thelancet.com/series/ARDS-2022

# Introduction

Acute respiratory distress syndrome (ARDS) is a clinical syndrome of diffuse lung inflammation and oedema that commonly causes acute respiratory failure. ARDS was identified in $1 0 \cdot 4 \%$ of intensive care unit admissions in 2016.1 Global awareness of ARDS has been heightened during the COVID-19 pandemic due to a sharp increase in the incidence of ARDS. This Series paper describes the current understanding of the pathophysiology of ARDS and summarises new developments in the identification of more homogeneous phenotypes within this highly heterogeneous clinical syndrome. The diagnosis and treatment of ARDS is reviewed in another paper in this Series.

# Traditional causes of ARDS

# Precipitating disorders

ARDS can be precipitated by a variety of causes including both infectious and non-infectious triggers; these triggers can injure the lung directly due to local inflammation, or indirectly as a result of systemic inflammatory and injury mediators (figure 1). Sepsis is the most common cause of ARDS,1 and both pulmonary sepsis from a variety of pathogens and non-pulmonary sepsis can lead to ARDS, with pulmonary sepsis (ie, pneumonia) being the most common cause. Among the non-infectious causes, pancreatitis, aspiration of gastric contents, and severe traumatic injuries with shock and multiple transfusions are the most common. Although not specific causes of ARDS, some exposures can increase the likelihood of developing ARDS from an inciting condition including alcohol use,2 cigarette smoking,3,4 and exposure to ambient air pollutants.5,6 Blood product transfusion can both cause ARDS (ie, transfusion-related acute lung injury)7 and increase risk in the setting of an inciting factor.8 Genetic heterogeneity might also increase the risk, but most identified variants are uncommon and attributable risk is small.9 Among more common genetic variants, the haptoglobin variant Hp-2, which has an allele frequency of approximately $60 \%$ in those with European ancestry, is associated with increased risk of ARDS in sepsis.10 Of note, most studies of the causes of ARDS have been done in high-income countries with patients predominantly of European ancestry; other causes might contribute to ARDS incidence elsewhere.

# Emerging causes

Since 2000, the pattern of disorders that incite ARDS has changed. Traumatic injury as the inciting cause for ARDS has decreased due to changes in mechanical ventilation, crystalloid resuscitation, and transfusion strategies. In 2018, e-cigarette and vaping-associated lung injury emerged as a new cause of ARDS that predominantly affects young, healthy users of e-cigarettes and other vaporised substances.11–13 Drug-induced ARDS can be caused by a variety of agents; chemotherapeutics are commonly implicated and immunotherapies including checkpoint inhibitors are an increasing cause of acute lung injury.14 Viral pneumonia has been recognised as a

Intensive Care, Amsterdam   
UMC—location AMC, University of Amsterdam, Amsterdam,   
Netherlands (L D J Bos PhD);   
Vanderbilt University School of Medicine, Medical Center   
North, Vanderbilt University, Nashville, TN, USA   
(Prof L B Ware MD)

# Search strategy and selection criteria

Correspondence to:   
Prof Lorraine B Ware, Vanderbilt   
University School of Medicine,   
Medical Center North, Vanderbilt   
University, Nashville,   
TN 37232, USA   
lorraine.ware@vumc.org

We searched PubMed and the references from relevant articles from Jan 1, 2000 to April 30, 2022. Although we primarily included articles published since 2017, we also cite relevant reviews, commonly referenced older publications, and articles of historical importance. For the review of papers related to subphenotypes of acute respiratory distress syndrome we searched PubMed using the following terms: ((“sub-phenotype”[All Fields] OR “phenotype”[All Fields] OR “morphology”[All Fields] OR “subphenotype”[All Fields]) AND (“respiratory distress syndrome”[MeSH Terms] OR “ards”[Title/Abstract] OR “acute respiratory distress syndrome”[Title/Abstract] OR “ALI”[Title/Abstract] OR “acute lung injury”[Title/Abstract]).

![](images/748f6e9785ae61edbd5ee03bbaa5dba3391f99b1b8b663caeae3d9d637808807.jpg)  
Figure 1: Causes of acute respiratory distress syndrome Acute respiratory distress syndrome (ARDS) can result from indirect, extrapulmonary or direct, pulmonary lung injury. The most common extrapulmonary risk factors for ARDS are sepsis, pancreatitis, and trauma, while pneumonia and aspiration are the most common pulmonary risk factors; among all risk factors pneumonia (nonpulmonary sepsis) is the most common.

cause since the first description of ARDS,15 but strains that are more likely to cause ARDS emerge periodically. These include SARS-CoV (2003), H1N1 influenza (2009), MERS-CoV (2012), and most notably the SARS-CoV-2 virus (2019) that led to the COVID-19 pandemic, which as of this report has already killed at least 6 million people globally, the majority via ARDS.16

The pathophysiology of ARDS is complex and our understanding is incomplete due to the inherent limitations of animal models for ARDS and the challenges of mechanistic studies in humans, particularly during acute critical illness. Mechanisms of ARDS include activation and dysregulation of multiple overlapping and interacting injury response pathways, inflammation, and coagulation both in the lung and systemically.17 Importantly, many of these pathways are central to the normal host response to infection or injury, but excessive and diffuse activation is harmful. The degree of lung versus systemic involvement and the degree to which specific pathways are involved in individual patients is variable and contributes to the clinical and biological heterogeneity of ARDS. Approaches to reduce ARDS heterogeneity through phenotyping are discussed in the second half of this review.

# Pathophysiology

The classic pathological finding in the lung is diffuse alveolar damage, although it is only identified in around $45 \%$ of post-mortem lung specimens from patients with a clinical diagnosis of ARDS.18,19 Diffuse alveolar damage is characterised by neutrophilic alveolitis and hyaline membrane deposition. Other pathological findings in autopsy series include bilateral pneumonia, and less common conditions such as diffuse alveolar hemorrhage.19 In diffuse alveolar damage, hyaline membranes are fibrinrich proteinaceous deposits that form along the denuded alveolar basement membrane in areas of substantial epithelial lung injury. Ultrastructural studies have clearly delineated the importance of lung epithelial and endothelial injury in ARDS,20 establishing injury to the alveolar–capillary barrier as having a key role in ARDS pathophysiology. However, the prevalence of histopathological patterns in ARDS is uncertain, as lung biopsies are only taken in selected instances of nonresolving ARDS and autopsy findings only represent the severely ill minority who do not survive.21 Comprehensive histopathological findings in large numbers of patients with acute ARDS are not available.

# Injury to the lung’s epithelial and endothelial barriers

The alveolar–capillary barrier is made of thin layers of alveolar epithelial cells and capillary endothelial cells; these layers are separated only by a thin basement membrane to facilitate gas exchange. Injury to both layers of the alveolar–capillary barrier is typical of ARDS and directly contributes to the characteristic physiological abnormalities (figure 2).17

The lung epithelium is composed of a tight layer of flat alveolar epithelial type I cells with interspersed alveolar epithelial type II cells. The severity of lung epithelial injury is an important determinant of survival in patients with ARDS.22 In ARDS, lung epithelial injury can vary in severity. Injury ranges from epithelial activation with expression of adhesion molecules and activation of proinflammatory and procoagulant pathways, small increases in paracellular permeability due to injury to intercellular junctions, or frank necrosis of epithelial cells with denuding of the alveolar basement membrane (figure 2). Damage to the tight lung epithelial barrier facilitates alveolar flooding and impairs the transport of fluid by the alveolar epithelium, the normal mechanism for maintaining a dry airspace.23 Injury to type II cells might impair surfactant production;24 surfactant can also be inactivated by alveolar flooding.25 Disease-associated molecular patterns are released into the airspace due to necrosis of lung epithelial cells with leakage of intracellular contents, which can amplify proinflammatory signalling.26 Concomitant injury and shedding of the lung epithelial glycocalyx, a layer of glycosaminoglycans and proteoglycans that covers the alveolar surface, is also proinflammatory.27 Activation and injury of the alveolar epithelium also leads to the shedding of anticoagulant molecules and the release of tissue factor from the lung epithelium into the alveolar space.28,29 These changes favour intra-alveolar fibrin formation, which drives hyaline membrane formation. The alveolar epithelium is an important barrier against pathogens and can secrete antibacterial proteins such as surfactant proteins A and D;30 therefore, epithelial injury can also increase susceptibility to secondary infection.

The capillary endothelium forms the barrier between circulating blood cells and plasma and the lung interstitium and airspace. Injury to the lung endothelium is a key feature of ARDS and is characterised by the formation of gaps between endothelial cells and upregulation of adhesion molecules such as P-selectin and E-selectin and endothelial injury mediators such as angiopoietin-2.31–33 A variety of stimuli can trigger endothelial injury including circulating pathogens or their products, endogenous disease-associated molecular patterns, proinflammatory cytokines, and cell-free haemoglobin.34 Severe injury to the lung epithelium can also trigger injury to the lung endothelium. Although the mechanisms are not well understood, direct cell-to-cell communication and transfer of reactive oxygen species between lung epithelial and endothelial cells probably contribute.35 As with the lung epithelium, the endothelium is covered with a glycocalyx that is easily injured and shed, exposing adhesion molecules and favouring oedema formation.36 Endothelial injury causes the shedding of anticoagulant molecules on the endothelial surface such as thrombomodulin and the endothelial protein C receptor, and upregulation of procoagulant molecules favouring microvascular thrombus formation.37

# Physiological consequences of injury to the alveolar– capillary barrier

Injury to the lung’s epithelial and endothelial barriers has direct physiological consequences, which are responsible for the typical changes in gas exchange, work of breathing, and radiographical findings (table 1) in ARDS. The increased permeability of the lung’s endothelial and epithelial barriers precipitates alveolar flooding due to leakage of protein-rich pulmonary oedema from the vasculature into the airspaces. Alveolar flooding is further exacerbated by the breakdown of normal transport mechanisms for alveolar epithelial fluid, which normally would compensate by pumping alveolar oedema into the interstitium, to be reabsorbed into the circulation and cleared via the lymphatics.38 Alveolar flooding has major consequences including severe impairment of gas exchange due to ventilation–perfusion mismatch and shunt, inactivation of surfactant leading to microatelectasis and end-expiratory alveolar collapse, and decreased lung compliance requiring higher inspiratory pressures and increased work for breathing. Activation of procoagulant pathways on the lung’s endothelium can lead to lung microvascular thromboses which increase dead space; increased dead space ventilation contributes to severe gas-exchange impairments and is associated with higher mortality in ARDS.39 Microvascular thromboses and severe damage to the microvascular bed can lead to pulmonary arterial hypertension and acute right ventricular dysfunction, both of which contribute to poor clinical outcomes.40

# Normal epithelium

• Airspace is dry   
• Intact epithelial tight   
junctions   
• Intact epithelial glycocalyx   
• Normal surfactant production   
• Vectorial sodium and   
chlorine transport

![](images/2d228580a584c7ca530515cee447c7dfa722bd6051dea0bb1c8a1cac8d36200c.jpg)  
A Normal alveolar–capillary barrier

# B Mild injury

# Epithelial injury

• Mild oedema formation   
• Disrupted tight junctions   
• Decreased surfactant production   
• Impaired sodium and chlorine transport   
• Mild glycocalyx shedding   
• Activated epithelial cells secrete chemokines and express adhesion molecules   
• Intact endothelial   
tight junctions   
• Intact endothelial   
glycocalyx   
• No adhesion   
molecules displayed   
• White blood cells   
including neutrophils   
(ie, PMNs), RBCs, and   
platelets transit the   
capillary freely

# Normal endothelium

![](images/a9556ef36f85a12a3136a345a207a5faef217ac42117994fe7e67d77bda7fd22.jpg)

# Endothelial injury

• Disrupted tight   
junctions   
• Paracellular fluid   
leakage from plasma   
• Injured endothelial   
glycocalyx   
• Upregulated   
adhesion molecules   
• RBCs might be   
injured transiting   
the capillary   
• Adherent PMNs

# Endothelial injury

• More severe endothelial disruption with transit of fluid out of the capillary   
• Loss of endothelial glycocalyx   
• RBC injury   
• PMN transmigration   
• Platelet microthrombi

![](images/4432b9f7bcfb02dadfc43c298f239949039dc98707bdc420b72674db1f200727.jpg)  
Figure 2: Injury to alveolar–capillary barrier   
(A) The normal alveolar–capillary membrane is a barrier that prevents the development of alveolar oedema. With the progression from mild (B) to severe injury (C), the alveolar–capillary barrier becomes more permeable, leading to alveolar oedema. ENaC=epithelial sodium channel. PMN=polymononuclear cells. RBC=red blood cell.

# Lung and systemic inflammation

Both local and systemic acute inflammation are prominent features of ARDS that contribute to lung epithelial and endothelial injury. Neutrophils are not normally found in healthy airspaces. Early in the course of ARDS, neutrophils migrate from the lung vasculature into the airspace and can release a variety of injurious mediators including reactive oxygen species, proteases, and proinflammatory lipid-derived mediators such as prostaglandins and leukotrienes.41 Neutrophilic extracellular traps composed of DNA, histones, and proteases are also released into the airspace during these pathophysiological processes and can increase inflammation by activating the NRLP3 inflammasome, which initiates local release of interleukin-1- $\beta$ and interleukin-18.42

<table><tr><td></td><td>Physiological manifestations</td><td>Clinical findings</td></tr><tr><td>Alveolar-capillary barrier injury with interstitialandalveolaroedema formation</td><td> Decreased lung compliance</td><td>Increased workofbreathing</td></tr><tr><td>Difuse alveolar filing</td><td>Ventilation perfusion mismatch and shunt</td><td>Severe hypoxaemia with difuse bilateral radiographic opacities</td></tr><tr><td>Surfactant inactivation and decreased production</td><td>End-expiratory alveolar collapse</td><td>Favourable response to positive end-expiratory pressure</td></tr><tr><td>Plateletand endothelialactivation with lung microvascular thrombosis,and obstruction or destruction ofthe lung vascular bed</td><td>Increaseddead spaceventilation and pulmonary arterial hypertension</td><td>High minute ventilation,hypercarbia, right heart failure</td></tr><tr><td>Leak of lung inflammatory mediators into systemic circulation</td><td>Systemic inflammatory response syndrome</td><td>Multi-organ dysfunction</td></tr></table>

Neutrophil recruitment is mostly done by tissueresident and recruited macrophages.43 Macrophage pattern recognition receptors bind disease-associated or pathogen-associated molecular patterns, which activate macrophages to a proinflammatory phenotype leading to the release of proinflammatory cytokines and neutrophil chemoattractants such as interleukin-8. Lung epithelial cells can also release neutrophil chemoattractants.44 Neutrophils enter the lung mostly through the capillary wall, in response to chemoattractant gradients, moving paracellularly between endothelial cells and alveolar epithelial cells in pathways that appear to be regulated by interstitial fibroblasts,41 although transcytosis has also been observed.

In addition to macrophages, current evidence suggests that an array of immune cells, including lymphocyte subsets and dendritic cells,45 along with networks of cytokines, regulate intra-alveolar inflammation in ARDS.46 In addition to lung inflammation, systemic inflammation is common in patients with ARDS and probably contributes to the common occurrence of nonpulmonary organ failure in ARDS. Interactions between the lung and other organs such as the kidneys47 and the brain48 might also contribute to non-pulmonary organ dysfunction; both kidney and brain injury are associated with poor short-term and long-term outcomes for ARDS.49

Role of mechanical ventilation in propagating lung injury The recognition that mechanical ventilation for treatment of ARDS contributes to a cycle of lung injury and inflammation has revolutionised care for patients with ARDS. In experimental studies, ventilation of the normal lung with high volumes and pressures can induce acute lung injury that replicates the pathophysiological features of ARDS.50 Mechanical ventilation can also exacerbate lung injuries in experimental settings, enhancing both inflammation and oedema.51 This is now well validated in human ARDS, for which it is established that ventilation with high tidal volumes or high inspiratory pressures or both can exacerbate acute lung injury by a process that is termed ventilator-induced or ventilator-associated lung injury.

Several mechanisms of ventilator-induced lung injury have been described.52 Given the regional heterogeneity of injury within the lung,53 and the regional variability of stressors applied to the lung by mechanical ventilation, different mechanisms of ventilator-induced lung injury probably affect the lung simultaneously. Volutrauma and barotrauma are physiologically coupled and refer to lung injury from overdistension and elevated transpulmonary pressures.52 In ARDS, volutrauma and barotrauma result from decreased compliance of the injured lung and the inhomogeneity of alveolar consolidation in ARDS such that some areas, usually the dependent areas, cannot participate in alveolar ventilation. This concept, that only a small proportion of the lung parenchyma participates in alveolar ventilation in ARDS, has been termed baby lung.54 Although the concept of ventilator-induced lung injury focuses on the injurious effects of mechanical ventilation, the same injury pathways might be activated by vigorous spontaneous inspiratory efforts, which produce elevated transpulmonary pressures on the basis of very negative pleural pressures.55

On a cellular level, repetitive cyclic stretching of the lung epithelium activates mechanosensitive proinflammatory pathways with the production of cytokines and chemokines. Cyclic stretch can cause the formation of gaps between epithelial cells, the detachment of cells from the basement membrane, and cell death. In experimental models of ventilator-induced lung injury, both lung endothelial and epithelial cells show stretchinduced cytosolic calcium oscillation, which alters alveolar ATP production.56 Mechanical stretch also impairs alveolar epithelial fluid transport.57 End-expiratory collapse of alveoli leading to repetitive opening and closing of alveoli can also injure the lung. This form of ventilator-induced lung injury, termed atelectrauma, is a result of the loss of normal surfactant function due to its impaired production and inactivation by alveolar flooding. Repetitive opening and closing of alveoli is thought to exacerbate lung injury by exposing the distal airspaces to high shear stress, which causes direct mechanical injury to the lung epithelium.58

Ventilator-induced lung injury can also have systemic consequences.52 Proinflammatory cytokines and chemokines, which are further augmented in the injured lung by injurious mechanical ventilation, can enter the systemic circulation and contribute to the systemic inflammatory response and to non-pulmonary organ failure.59,60 Delivery of mechanical ventilation at high volumes and pressures also increases intrathoracic pressure. The resulting impairment in cardiac filling can reduce cardiac output and cause hypotension and shock.

# Resolution, repair, and fibrosis

Resolution of ARDS is a multifaceted process that includes removal of inflammatory cells and cytokines, clearance of alveolar oedema, and repair of the alveolar– capillary barrier (panel). Resolution of inflammation is a coordinated process that requires downregulation of proinflammatory pathways and upregulation of antiinflammatory pathways. T-regulatory cells have a vital role in coordinating this process.46 Neutrophils are cleared from the airspace through apoptosis and phagocytic clearance by alveolar macrophages.61 Proresolving mediators, including lipoxins and resolvins, are a family of bioactive lipid mediators that might also have a role in resolution of lung injury and inflammation.62

Resolution of pulmonary oedema requires a change in the balance of oedema formation and oedema clearance to favour net alveolar fluid removal. Both the severity of injury to the alveolar–capillary barrier and the degree of elevation of microvascular pressure contribute to oedema formation;63 reversal of barrier hyperpermeability and restoration of normal microvascular pressures reduce the forces that favour oedema formation.64 Restoration of alveolar epithelial fluid transport requires the regeneration of the alveolar epithelium, which can be necrotic in ARDS. Several cells can act as progenitors to repopulate the epithelium, and their relative roles might depend on the severity of epithelial injury.65,66 Once a tight epithelial barrier is restored, various endogenous factors can upregulate alveolar fluid clearance, including catecholamines and corticosteroids.67

The role of interstitial cells, such as fibroblasts, in the acute and resolution phases of ARDS is poorly understood, reflecting the difficulty of studying the interstitial compartment, particularly in humans. Profibrotic pathways are triggered as early as the first day of ARDS and can lead to lung fibrosis. Fibrosis can impede ventilator weaning, and cause long-term impairment of lung function with restrictive physiology and decreased diffusing capacity. Post-ARDS lung fibrosis used to be common, but has declined since 2000 with the adoption of lung-protective ventilation, suggesting that ventilatorinduced lung injury was a major contributor to the activation of profibrotic pathways. With the SARS-CoV-2

# Panel: Pathways that restore homoeostasis in the resolution of acute respiratory distress syndrome

# Resolution of inflammation

$\cdot$ Neutrophil apoptosis and clearance remove excess neutrophils from airspace   
• Alveolar macrophage phenotypes shift from proinflammatory to anti-inflammatory   
• Change of lung lymphocyte populations to T-regulatory cells, which orchestrate recovery   
• Chemokine and cytokine balance shifts from proinflammatory to anti-inflammatory   
• The profile of lipid mediators in the airspace transitions from proinflammatory leukotrienes and prostaglandins to proresolving lipid mediators such as lipoxins and resolvins

# Restoration of the alveolar–capillary barrier

• Lung epithelial growth factors trigger epithelial   
regeneration through replication and differentiation of resident lung stem-cell populations   
• Restoration of lung epithelial integrity restores alveolar   
epithelial fluid transport allowing clearance of alveolar   
oedema   
• Balance of endothelial injury and repair mediators shifts   
from proinjury angiopoietin-2 dominant to prorepair angiopoietin-1 dominant   
• Restoration of lung endothelial and epithelial glycocalyces

pandemic, however, post-ARDS fibrosis has increased as a consequence of severe COVID-19 ARDS. This increase in post-ARDS fibrosis might reflect the high severity and extended duration of ARDS in some COVID-19 patients, which leads to refractory hypoxaemia that is difficult to manage without causing ventilator-induced lung injury.68

# Phenotyping ARDS

ARDS has been discussed in the previous sections as one clinical syndrome with distinct causes, but a common pathophysiology culminating in protein-rich pulmonary oedema. There is ample evidence, however, that ARDS is both clinically and biologically heterogeneous. Since the original description of ARDS in 1967, there have been discussions about the right way to subcategorise ARDS patients.69,70 The major advantage of not subcategorising patients with ARDS and instead using a simple syndromic definition is that clinical recognition is increased and treatment strategies can be evaluated in large clinical trials. Trials in large cohorts of heterogeneous ARDS patients reduced mortality from ARDS by proving the value of low tidal volume,71 restrictive fluid strategy,64 and prone positioning72 as supportive therapies. Pharmacological interventions, however, have not given clear survival benefits in unselected ARDS populations.73 These null results can be attributed to the substantial heterogeneity that is observed among patients fulfilling ARDS criteria.74 The subcategorisation of these patients further into more

<table><tr><td></td><td>Definition</td><td>Classification of a patient</td></tr><tr><td>Phenotype</td><td>Clinicallyobservable setoftraits resulting froman interactionof genotype and environmental exposures</td><td>ARDS</td></tr><tr><td>Subgroup</td><td>Asubset of patients in a phenotype,basedonany cutoff inany variable; this cutoffARDS with low PaO:FiO can be arbitrary and frequently patients falljust on either side of it resulting in patients switching subgroups</td><td></td></tr><tr><td> Subphenotype</td><td>Subgroupthatcanbereliablydiscriminatedfromothersubgroupsbasedona data-drivenassessment of a multidimensionalassessment of traits</td><td> Hyperinflammatory subphenotype</td></tr><tr><td>Endotype</td><td>Subphenotype with distinct functional or pathobiological mechanism, which preferably responds differently to a targeted therapy</td><td>Unknown</td></tr><tr><td colspan="3">ifereces oxygen.FiO2=inspired fraction of oxygen.</td></tr><tr><td colspan="3">Table2:Nomenclaturefrequentlyencounteredindescribing theheterogeneityofacuterespiratorydistressyndrome</td></tr></table>

![](images/7de8c3ff0d09f8c31dfe04aff382b40c0e7d2faf0a441df191d6fbcaade2965c.jpg)  
Figure 3: Prognostic and predictive enrichment examples in respiratory and critical care   
The x axis shows prognostic enrichment, which leads to an increase in the frequency of the primary endpoint resulting in a higher absolute risk reduction at a similar relative risk reduction in the enriched population. The y axis shows predictive enrichment, which leads to an improvement in the relative risk reduction resulting in a higher absolute risk reduction independent of the frequency of the primary endpoint in the enriched population. The pink circles show the extent of prognostic and predictive enrichment for each of the examples given in table 2. ARDS=acute respiratory distress syndrome. EGFR=epidermal growth factor receptor. NSCLC=non-small-cell lung cancer. PEEP=positive end-expiratory pressure.

# Phenotypes, subphenotypes, and endotypes

ARDS can be split into subgroups based on clinical, imaging, physiological, or biomarker data (table 2). Division of the ARDS population on any criterion, however arbitrary, generates a subgroup. However, these only qualify as subphenotypes when they are reliably discriminable. For example, an arbitrary cutoff of a single variable always provides two subgroups, but patients at the border of this cutoff will commonly change groups upon remeasurement. Therefore, data-driven approaches in a multivariate space are typically needed to discern reliably distinct subgroups.78 A subphenotype is referred to as an endotype when it is defined by a distinct functional or pathobiological mechanism, and preferably responds differently to a targeted therapy compared with patients who do not have that endotype.75

Subphenotypes and endotypes improve our understanding of ARDS by identifying subgroups of patients that share a common pathophysiology and their use might ultimately result in the identification of treatable traits.79 Phenotyping can increase our understanding of ARDS pathophysiology and be used to improve clinical trial design in two ways.75,80 First, preferential inclusion of a subphenotype with a higher likelihood of developing the primary outcome provides an increase in statistical power, even when the relative risk reduction of the studied intervention is unchanged. This method is referred to as prognostic enrichment and has been successfully made use of in studies of pulmonary and critical care medicine (figure 3). Second, selective inclusion of patients with an endotype who are randomly assigned to receive an intervention that targets that endotype, will probably benefit more than an unselected population. This potential improvement in relative risk reduction by patient selection is called predictive enrichment (figure 3).

homogeneous groups is referred to as phenotyping, the promise of which is that a more precise intervention can be delivered.75 The benefit of a more targeted intervention must be weighed against the risk of creating ever smaller and rarer subgroups, making both clinical trials and patient care increasingly complicated.76,77

# Subphenotypes by cause

ARDS can be incited by different pulmonary and extrapulmonary risk factors (figure 1). Patients with direct pulmonary causes have more alveolar epithelial injury and alveolar inflammation than patients with indirect non-pulmonary causes.81 For example, caspase1-dependent pathways in the alveolar space are particularly upregulated in patients with pulmonary causes of ARDS.82 When an extrapulmonary risk factor leads to ARDS, endothelial injury and systemic inflammation are increased.81,83 Given that extrapulmonary causes of ARDS affect the whole lung via endothelial dysfunction rather than the more localised injury expected in a direct pulmonary cause, a more diffuse injury pattern is common, which might result in a better response to lung recruitment strategies such as increased positive end-expiratory pressure.84 Biological and physiological heterogeneity between pulmonary and extrapulmonary risk factors for ARDS has been a focus of research for decades, but has not resulted in therapeutic breakthroughs.

![](images/ffe165f766a64132a931213b77bb7aadfe5ec9b8d294564f76e8a36fdbc8bf46.jpg)  
Figure 4: Systemic versus alveolar inflammation in the development of acute respiratory distress syndrome   
Systemic and alveolar inflammation are not necessarily correlated in patients with acute respiratory distress syndrome (ARDS). The panels show differences between systemic hypoinflammatory (A, C) and hyperinflammatory (B, D) inflammation, and the differences between alveolar hypoinflammatory (A, B) and hyperinflammatory (C, D) inflammation. Although these panels illustrate the extreme situations of systemic without alveolar inflammation and alveolar without systemic inflammation, the severity of systemic and alveolar inflammation exists on a spectrum that probably varies considerably from patient to patient, contributing to heterogeneity. (A) The normal alveolus, without inflammation or injury. (B) The changes observed in the hyperinflammatory subphenotype, which is characterised by systemic inflammation, endothelial dysfunction, and coagulation. Without alveolar inflammation, the injury caused by inflammation is driven from the systemic compartment towards the alveolar compartment (yellow arrow), resulting in increased permeability and alveolar oedema. (C) The changes in patients with alveolar hyperinflammation without a systemic hyperinflammatory subphenotype. Alveolar epithelial cells, alveolar macrophages, and neutrophils have a central role in proinflammatory cytokine production. Epithelial cells and macrophages are essential in production of proinflammatory molecules. Neutrophils produce various injurious molecules that damage type 1 and type 2 pneumocytes resulting in increased levels of pneumocyte injury markers. Without systemic inflammation, the injury caused by inflammation in this scenario is driven from the alveolar towards the systemic compartment (yellow arrow), also resulting in increased permeability and alveolar oedema. (D) The combined presence of systemic and alveolar hyperinflammation. Under these circumstances, inflammation induces lung injury, increased permeability, and alveolar oedema from both directions. ANG2=angiopoietin-2. ARDS=acute respiratory distress syndrome. CC16=clara cell protein. IL=interleukin. KL-6=Krebs von den Lungen-6. MMP=matrix metalloproteinase. NET=neutrophil extracellular trap. PAI-1=Plasminogen activator inhibitor-1. ROS=reactive oxygen species. sRAGE=soluble receptor for advanced glycation end products. Sp-D=surfactant protein-D. TNF=tumour necrosis factor. TNFR1=TNF receptor 1.

By contrast, substantial progress has been made in the prevention of ARDS for different specific causes. Plasma transfusion from female donors rather than male donors was identified as a major risk factor for transfusion-related acute lung injury;85,86 use of male-only fresh-frozen plasma has substantially decreased transfusion-related acute lung injury.87,88 Patients with severe traumatic injuries are at high risk for ARDS, probably due to additive injury from haemorrhagic shock, mechanical ventilation, resuscitation, and multiple blood transfusions,85,89 and changes in how these interventions are done can reduce the prevalence of hospital-acquired ARDS.90

COVID-19-related ARDS, in which immune dysfunction drives the development of ARDS, exemplifies the value of assessing a sufficiently homogeneous population for effective targeted pharmacological treatment through predictive enrichment.91,92 For the most part, patients with ARDS unrelated to COVID-19 have not responded favourably to anti-inflammatory approaches; by contrast, patients with COVID-19-related ARDS showed benefit from corticosteroid treatment in the RECOVERY trial.93 Patients with COVID-19 who require respiratory support with high flow nasal cannula or non-invasive ventilation benefited from early administration of interleukin-6 inhibitors94 and inhibitors of the Janus kinase–signal transducers and activators of transcription (JAK–STAT) pathway,95 suggesting that immunomodulation prevented further lung injury.

# Biological subphenotypes

In 2014, hypoinflammatory and hyperinflammatory subphenotypes of ARDS were identified by use of latent class analysis. This modelling strategy identified two homogeneous subgroups using a dataset that included clinical characteristics and plasma biomarkers of proinflammatory host response from two ARDS clinical trial populations.96 The hyperinflammatory subphenotype had higher plasma concentrations of IL-6, IL-8, and tumour necrosis factor receptor-1, and lower concentrations of bicarbonate and protein-C than the hypoinflammatory subphenotype. Patients with the hyperinflammatory subphenotype had extrapulmonary sepsis as a risk factor for ARDS more frequently than those who were hypoinflammatory, and more often required vasopressors, confirming findings from research into subphenotypes that are based on underlying cause; however, sepsis or use of vasopressors alone was not enough to separate the two subphenotypes. Hyperinflammatory ARDS patients also stayed longer in intensive care units, had fewer ventilator-free days, and had higher 90-day mortality, suggesting that the hyperinflammatory phenotype might be useful for prognostic enrichment. Multiple studies have since identified subphenotypes with the same clinical, biological, and prognostic characteristics, although different descriptors such as reactive and uninflamed were used.96–101

Notably, heterogeneity of treatment effect was also observed between these biological subphenotypes suggesting they might be of value for predictive enrichment. Reanalysis of randomised controlled trials revealed a differential response to positive end-expiratory pressure strategy, fluid strategy, and simvastatin treatment between the hypoinflammatory and hyperinflammatory subphenotype.96,98,99 The differential treatment effect for simvastatin was, however, not seen for rosuvastatin.100 The beneficial effects of a higher positive end-expiratory pressure ventilation strategy were only observed in patients with the hyperinflammatory subphenotype, which could be driven by more diffuse injury to the lung in the setting of systemic proinflammatory response. To facilitate the rapid identification of the hyperinflammatory and hypoinflammatory phenotypes in clinical practice, a parsimonious biomarker model and a machine-learningderived model based only on clinical data have been proposed.102–104 Using the machine-learning model, the heterogeneity of treatment effect for positive endexpiratory pressure was confirmed in an observational study.103,104

The benefit of treatment with simvastatin in the hyperinflammatory subphenotype probably comes from immunomodulation.105 Patients with the reactive subphenotype, which is similar to the hyperinflammatory subphenotype in many regards, showed altered blood leukocyte response suggestive of profound systemic neutrophil activation, which might explain why immunomodulation would affect these subphenotypes differentially.106,107 The differences in systemic inflammatory response that drive the distinction between the hypoinflammatory and hyperinflammatory subphenotypes in ARDS are not necessarily mirrored in the alveolar host response; discordant levels of bronchoalveolar lavage and systemic proinflammatory cytokines have been observed.108 Therefore, inflammatory heterogeneity in ARDS is at least two-dimensional; with subphenotypes in systemic and alveolar inflammation (figure 4). We need to better understand the heterogeneity in alveolar host response, how it relates to subphenotypes that are based on underlying cause, and its potential for use in predictive enrichment.

# Radiological subphenotypes

Although ARDS is classically characterised by diffuse bilateral alveolar infiltrates on chest radiograph, CT has identified two distinct subphenotypes of ARDS on the basis of radiographic lung morphology. Lungs with diffuse and patchy loss of aeration (ie, the non-focal subphenotype) respond well to alveolar recruitment strategies with improved gas exchange and lung mechanics, while lungs with predominant dorsal–inferior consolidations (the focal subphenotype) respond better to prone positioning.109 Importantly, assessment of these morphological subphenotypes must be done at $5 \ \mathrm { c m \ H } _ { 2 } \mathrm { O }$ positive endexpiratory pressure as a higher positive end-expiratory pressure results in alveolar recruitment and an underestimation of consolidated lung tissue. CT imaging is necessary, as differentiating these phenotypes using conventional chest radiography is challenging and can result in misclassification.110 Alternatively, lung ultrasound algorithms have been developed.111

In the first randomised controlled trial that used predictive enrichment in ARDS, personalised treatment based on lung morphology subphenotypes of ARDS was compared with standard of care ventilation.110 There was no overall mortality benefit for patients randomised to mechanical ventilation personalised to lung morphology.

Given the infrequent use of CT imaging in the study and reliance on chest radiography, $20 \%$ of patients were misclassified, with poor interobserver agreement in the interpretation of chest images. Patients with correctly classified lung morphology benefited from a personalised ventilation strategy with a $10 \%$ decrease in mortality, while patients who were misclassified had a substantial increase in mortality when exposed to a misaligned personalised ventilation strategy.110 The results of this study show that accurate classification is imperative before delivering a subphenotype-specific intervention.

# Physiological subphenotypes

Latent class analysis using quantitative CT imaging data and physiological characteristics such as shunt fraction and dead space ventilation identified two subphenotypes with differential responses to lung recruitment.112 Patients with the recruitable subphenotype had more dead space, more non-inflated or less than normally inflated lung tissue on CT, lower compliance of the respiratory system, a lower partial pressure of arterial oxygen $\left( \mathrm { P a O } _ { 2 } \right)$ to inspired fraction of oxygen $\mathrm { ( F i O _ { 2 } ) }$ ratio, and a higher risk of death. An increase in positive end-expiratory pressure from 5 to $1 5 \ \mathrm { c m \ H _ { 2 } O }$ led to greater improvement in lung aeration and ${ \mathrm { P a O } } _ { 2 } { : } \mathrm { F i O } _ { 2 }$ in patients with the recruitable subphenotype. Furthermore, these patients showed an improvement in the compliance of the respiratory system and a reduction in dead space ventilation after an increase in positive end-expiratory pressure.

All the subphenotyping approaches discussed used static data, typically derived within 24–48 hours after intubation and therefore ignored dynamic changes that could also provide insight into the heterogeneity of ARDS. The stability of biological subphenotypes was confirmed on day three of mechanical ventilation.113 Static and dynamic modelling approaches were compared in a study of respiratory physiology in patients with COVID-19-related ARDS.114 The static approach did not yield subphenotypes, irrespective of the time window from which the data were derived. An adaptation of latent class analysis that can make use of longitudinal data identified two subphenotypes driven by dead space ventilation and the energy transferred to the patient’s respiratory system by the mechanical ventilator (mechanical power). This study clearly shows the added value of modelling time-dependent variation, in understanding ARDS heterogeneity.115

# Conclusions and future directions

The spectrum of underlying causes of ARDS indicates that clinicians from many disciplines will encounter this common clinical problem, particularly with the recent 10-fold or greater increase in ARDS incidence due to the COVID-19 pandemic. Although the pathophysiology of ARDS is complex and incompletely understood, we have summarised many pathways of injury that are common to most patients. Endogenous pathways for resolution of

ARDS are equally complex, but restore the lung to normal or near normal in most patients.

Current efforts to better identify and understand more homogeneous biological and clinical phenotypes of ARDS should improve our understanding of pathophysiological mechanisms and how they differ from patient to patient. However, subphenotyping of ARDS will only result in better patient outcomes when prospective randomised controlled trials find beneficial effects of subphenotype-driven treatment strategies. Currently, implementation of subphenotype-targeted clinical trials is limited both by the ability to rapidly identify biological subphenotypes at the bedside and our as yet incomplete understanding of how these subphenotypes might be harnessed for predictive enrichment. Overcoming these barriers is a central focus of current research in the pathophysiology and phenotyping of ARDS.

# Contributors

LDJB and LBW did the initial literature search, drafted the manuscript, and edited each revision of the manuscript.

# Declaration of interests

LDJB reports grants from Santhera Research, Health Holland, Dutch Lung Foundation, ZonMW, Amsterdam University Medical Center, and Innovative Medicine Initiative, outside the submitted work. LDJB has received personal fees from Santhera Research, Sobi, Scailyte, and Exvastat, outside the submitted work. LBW has received personal fees from Global Blood Therapeutics, Boehringer Ingelheim, Merck, Citius, and Foresee, and research funding (paid to Vanderbilt University Medical Center) from Genentech, Commonwealth Serum Laboratories, Behring, and Boehringer Ingelheim, outside the submitted work. LBW is also funded by the US National Institutes of Health (grant numbers: NIH R01HL158906 and NIH R01HL164937).

# Acknowledgments

LDB is supported by the Amsterdam UMC fellowship, Health Holland, and by the Dutch Lung Foundation (Longfonds) through the Dirkje Postma Award. We thank Diana Lim (Molecular Medicine Programme, University of Utah, Salt Lake City, Utah) for her assistance with illustrations.

# References

1 Bellani G, Laffey JG, Pham T, et al. Epidemiology, patterns of care, and mortality for patients with acute respiratory distress syndrome in intensive care units in 50 countries. JAMA 2016; 315: 788–800.   
2 Simou E, Leonardi-Bee J, Britton J. The effect of alcohol consumption on the risk of ARDS: a systematic review and meta-analysis. Chest 2018; 154: 58–68.   
3 Calfee CS, Matthay MA, Kangelaris KN, et al. Cigarette smoke exposure and the acute respiratory distress syndrome. Crit Care Med 2015; 43: 1790–97.   
4 Moazed F, Hendrickson C, Jauregui A, et al. Cigarette smoke exposure and ARDS in sepsis: epidemiology, clinical features, and biologic markers. Am J Respir Crit Care Med 2022; 205: 927–35.   
5 Reilly JP, Zhao Z, Shashaty MGS, et al. Low to moderate air pollutant exposure and acute respiratory distress syndrome after severe trauma. Am J Respir Crit Care Med 2019; 199: 62–70.   
6 Ware LB, Zhao Z, Koyama T, et al. Long-term ozone exposure increases the risk of developing the acute respiratory distress syndrome. Am J Respir Crit Care Med 2016; 193: 1143–50.   
7 Toy P, Looney MR, Popovsky M, et al. Transfusion-related acute lung injury: 36 years of progress (1985-2021). Ann Am Thorac Soc 2022; 19: 705–12.   
8 Gong MN, Thompson BT, Williams P, Pothier L, Boyce PD, Christiani DC. Clinical predictors of and mortality in acute respiratory distress syndrome: potential role of red cell transfusion. Crit Care Med 2005; 33: 1191–98.   
9 Reilly JP, Christie JD, Meyer NJ. Fifty years of research in ARDS genomic contributions and opportunities. Am J Respir Crit Care Med 2017; 196: 1113–21.   
10 Kerchberger VE, Bastarache JA, Shaver CM, et al. Haptoglobin-2 variant increases susceptibility to acute respiratory distress syndrome during sepsis. JCI Insight 2019; 4: 131206.   
11 Sommerfeld CG, Weiner DJ, Nowalk A, Larkin A. Hypersensitivity pneumonitis and acute respiratory distress syndrome from e-cigarette use. Pediatrics 2018; 141: e20163927.   
12 Moritz ED, Zapata LB, Lekiachvili A, et al. Update: characteristics of patients in a national outbreak of e-cigarette, or vaping, product use-associated lung injuries - United States, October 2019. MMWR Morb Mortal Wkly Rep 2019; 68: 985–89.   
13 Matsumoto S, Fang X, Traber MG, et al. Dose-dependent pulmonary toxicity of aerosolized vitamin E acetate. Am J Respir Cell Mol Biol 2020; 63: 748–57.   
14 Reuss JE, Suresh K, Naidoo J. Checkpoint inhibitor pneumonitis: mechanisms, characteristics, management strategies, and beyond. Curr Oncol Rep 2020; 22: 56.   
15 Ashbaugh DG, Bigelow DB, Petty TL, Levine BE. Acute respiratory distress in adults. Lancet 1967; 2: 319–23.   
16 Martin TR, Zemans RL, Ware LB, et al. New insights into clinical and mechanistic heterogeneity of the acute respiratory distress syndrome. Am J Respir Cell Mol Biol 2022; published online June 9. https://doi.org/10.1165/rcmb.2022-0089WS.   
17 Matthay MA, Zemans RL, Zimmerman GA, et al. Acute respiratory distress syndrome. Nat Rev Dis Primers 2019; 5: 18.   
18 Thille AW, Peñuelas O, Lorente JA, et al. Predictors of diffuse alveolar damage in patients with acute respiratory distress syndrome: a retrospective analysis of clinical autopsies. Crit Care 2017; 21: 254.   
19 Thille AW, Esteban A, Fernández-Segoviano P, et al. Comparison of the Berlin definition for acute respiratory distress syndrome with autopsy. Am J Respir Crit Care Med 2013; 187: 761–67.   
20 Bachofen M, Weibel ER. Structural alterations of lung parenchyma in the adult respiratory distress syndrome. Clin Chest Med 1982; 3: 35–56.   
21 Guerin C, Bayle F, Leray V, et al. Open lung biopsy in nonresolving ARDS frequently identifies diffuse alveolar damage regardless of the severity stage and may have implications for patient management. Intensive Care Med 2015; 41: 222–30.   
22 Ware LB, Matthay MA. Alveolar fluid clearance is impaired in the majority of patients with acute lung injury and the acute respiratory distress syndrome. Am J Respir Crit Care Med 2001; 163: 1376–83.   
23 Matthay MA, Folkesson HG, Clerici C. Lung epithelial fluid transport and the resolution of pulmonary edema. Physiol Rev 2002; 82: 569–600.   
24 Ikegami M, Falcone A, Whitsett JA. STAT-3 regulates surfactant phospholipid homeostasis in normal lung and during endotoxinmediated lung injury. J Appl Physiol 2008; 104: 1753–60.   
25 Zuo YY, Veldhuizen RAW, Neumann AW, Petersen NO, Possmayer F. Current perspectives in pulmonary surfactant— inhibition, enhancement and evaluation. Biochim Biophys Acta 2008; 1778: 1947–77.   
26 Tolle LB, Standiford TJ. Danger-associated molecular patterns (DAMPs) in acute lung injury. $J$ Pathol 2013; 229: 145–56.   
27 Rizzo AN, Haeger SM, Oshima K, et al. Alveolar epithelial glycocalyx degradation mediates surfactant dysfunction and contributes to acute respiratory distress syndrome. JCI Insight 2022; 7: e154573.   
28 Bastarache JA, Wang L, Wang Z, Albertine KH, Matthay MA, Ware LB. Intra-alveolar tissue factor pathway inhibitor is not sufficient to block tissue factor procoagulant activity. Am J Physiol Lung Cell Mol Physiol 2008; 294: L874–81.   
29 Wang L, Bastarache JA, Wickersham N, Fang X, Matthay MA, Ware LB. Novel role of the human alveolar epithelium in regulating intra-alveolar coagulation. Am J Respir Cell Mol Biol 2007; 36: 497–503.   
30 Crouch E, Wright JR. Surfactant proteins A and D and pulmonary host defense. Annu Rev Physiol 2001; 63: 521–54.   
31 Mulligan MS, Polley MJ, Bayer RJ, Nunn MF, Paulson JC, Ward PA. Neutrophil-dependent acute lung injury. Requirement for P-selectin (GMP-140). J Clin Invest 1992; 90: 1600–07.   
32 Newman W, Beall LD, Carson CW, et al. Soluble E-selectin is found in supernatants of activated endothelial cells and is elevated in the serum of patients with septic shock. $J$ Immunol 1993; 150: 644–54.   
33 Parikh SM, Mammoto T, Schultz A, et al. Excess circulating angiopoietin-2 may contribute to pulmonary vascular leak in sepsis in humans. PLoS Med 2006; 3: e46.   
34 Shaver CM, Wickersham N, McNeil JB, et al. Cell-free hemoglobin promotes primary graft dysfunction through oxidative lung endothelial injury. JCI Insight 2018; 3: 98546.   
35 Hough RF, Islam MN, Gusarova GA, Jin G, Das S, Bhattacharya J. Endothelial mitochondria determine rapid barrier failure in chemical lung injury. JCI Insight 2019; 4: 124329.   
36 Schmidt EP, Yang Y, Janssen WJ, et al. The pulmonary endothelial glycocalyx regulates neutrophil adhesion and lung injury during experimental sepsis. Nat Med 2012; 18: 1217–23.   
37 Livingstone SA, Wildi KS, Dalton HJ, et al. Coagulation dysfunction in acute respiratory distress syndrome and its potential impact in inflammatory subphenotypes. Front Med (Lausanne) 2021; 8: 723217.   
38 Ware LB, Matthay MA. Clinical practice. Acute pulmonary edema. N Engl J Med 2005; 353: 2788–96.   
39 Nuckton TJ, Alonso JA, Kallet RH, et al. Pulmonary dead-space fraction as a risk factor for death in the acute respiratory distress syndrome. N Engl J Med 2002; 346: 1281–86.   
40 Petit M, Jullien E, Vieillard-Baron A. Right ventricular function in acute respiratory distress syndrome: impact on outcome, respiratory strategy and use of veno-venous extracorporeal membrane oxygenation. Front Physiol 2022; 12: 797252.   
41 Lin WC, Fessler MB. Regulatory mechanisms of neutrophil migration from the circulation to the airspace. Cell Mol Life Sci 2021; 78: 4095–124.   
42 Lefrançais E, Mallavia B, Zhuo H, Calfee CS, Looney MR. Maladaptive role of neutrophil extracellular traps in pathogeninduced lung injury. JCI Insight 2018; 3: 98178.   
43 Aggarwal NR, King LS, D’Alessio FR. Diverse macrophage populations mediate acute lung inflammation and resolution. Am J Physiol Lung Cell Mol Physiol 2014; 306: L709–25.   
44 Thorley AJ, Ford PA, Giembycz MA, Goldstraw P, Young A, Tetley TD. Differential regulation of cytokine release and leukocyte migration by lipopolysaccharide-stimulated primary human lung alveolar type II epithelial cells and macrophages. J Immunol 2007; 178: 463–73.   
45 Perl M, Lomas-Neira J, Venet F, Chung CS, Ayala A. Pathogenesis of indirect (secondary) acute lung injury. Expert Rev Respir Med 2011; 5: 115–26.   
46 Reiss LK, Schuppert A, Uhlig S. Inflammatory processes during acute respiratory distress syndrome: a complex system. Curr Opin Crit Care 2018; 24: 1–9.   
47 Husain-Syed F, Slutsky AS, Ronco C. Lung-kidney cross-talk in the critically ill patient. Am J Respir Crit Care Med 2016; 194: 402–14.   
48 Balczon R, Lin MT, Lee JY, et al. Pneumonia initiates a tauopathy. FASEB J 2021; 35: e21807.   
49 Mart MF, Ware LB. The long-lasting effects of the acute respiratory distress syndrome. Expert Rev Respir Med 2020; 14: 577–86.   
50 Webb HH, Tierney DF. Experimental pulmonary edema due to intermittent positive pressure ventilation with high inflation pressures. Protection by positive end-expiratory pressure. Am Rev Respir Dis 1974; 110: 556–65.   
51 Corbridge TC, Wood LDH, Crawford GP, Chudoba MJ, Yanos J, Sznajder JI. Adverse effects of large tidal volume and low PEEP in canine acid aspiration. Am Rev Respir Dis 1990; 142: 311–15.   
52 Beitler JR, Malhotra A, Thompson BT. Ventilator-induced lung injury. Clin Chest Med 2016; 37: 633–46.   
53 Gattinoni L, Pesenti A, Avalli L, Rossi F, Bombino M. Pressurevolume curve of total respiratory system in acute respiratory failure. Computed tomographic scan study. Am Rev Respir Dis 1987; 136: 730–36.   
54 Gattinoni L, Pesenti A. The concept of “baby lung”. Intensive Care Med 2005; 31: 776–84.   
55 Yoshida T, Amato MBP, Kavanagh BP, Fujino Y. Impact of spontaneous breathing during mechanical ventilation in acute respiratory distress syndrome. Curr Opin Crit Care 2019; 25: 192–98.   
56 Kiefmann R, Islam MN, Lindert J, Parthasarathi K, Bhattacharya J. Paracrine purinergic signaling determines lung endothelial nitric oxide production. Am J Physiol Lung Cell Mol Physiol 2009; 296:[901-10   
57 Frank JA, Gutierrez JA, Jones KD, Allen L, Dobbs L, Matthay MA. Low tidal volume reduces epithelial and endothelial injury in acidinjured rat lungs. Am J Respir Crit Care Med 2002; 165: 242–49.   
58 Muscedere JG, Mullen JBM, Gan K, Slutsky AS. Tidal ventilation at low airway pressures can augment lung injury. Am J Respir Crit Care Med 1994; 149: 1327–34.   
59 Chiumello D, Pristine G, Slutsky AS. Mechanical ventilation affects local and systemic cytokines in an animal model of acute respiratory distress syndrome. Am J Respir Crit Care Med 1999; 160: 109–16.   
60 Ranieri VM, Suter PM, Tortorella C, et al. Effect of mechanical ventilation on inflammatory mediators in patients with acute respiratory distress syndrome: a randomized controlled trial. JAMA 1999; 282: 54–61.   
61 Bratton DL, Henson PM. Neutrophil clearance: when the party is over, clean-up begins. Trends Immunol 2011; 32: 350–57.   
62 Nijmeh J, Levy BD. Lipid-derived mediators are pivotal to leukocyte and lung cell responses in sepsis and ARDS. Cell Biochem Biophys 2021; 79: 449–59.   
63 Sibbald WJ, Short AK, Warshawski FJ, Cunningham DG, Cheung H. Thermal dye measurements of extravascular lung water in critically ill patients. Intravascular starling forces and extravascular lung water in the adult respiratory distress syndrome. Chest 1985; 87: 585–92.   
64 Wiedemann HP, Wheeler AP, Bernard GR, et al. Comparison of two fluid-management strategies in acute lung injury. N Engl J Med 2006; 354: 2564–75.   
65 Aspal M, Zemans RL. Mechanisms of ATII-to-ATI cell differentiation during lung regeneration. Int J Mol Sci 2020; 21: E3188.   
66 Hogan BLM, Barkauskas CE, Chapman HA, et al. Repair and regeneration of the respiratory system: complexity, plasticity, and mechanisms of lung stem cell function. Cell Stem Cell 2014; 15: 123–38.   
67 Matthay MA. Resolution of pulmonary edema. Thirty years of progress. Am J Respir Crit Care Med 2014; 189: 1301–08.   
68 Compagnone N, Palumbo D, Cremona G, et al. Residual lung damage following ARDS in COVID-19 ICU survivors. Acta Anaesthesiol Scand 2022; 66: 223–31.   
69 Petty TL. The adult respiratory distress syndrome (confessions of a ‘lumper’). Am Rev Respir Dis 1975; 111: 713–15.   
70 Murray JF. The adult respiratory distress syndrome (may it rest in peace). Am Rev Respir Dis 1975; 111: 716–18.   
71 Brower RG, Matthay MA, Morris A, Schoenfeld D, Thompson BT, Wheeler A. Ventilation with lower tidal volumes as compared with traditional tidal volumes for acute lung injury and the acute respiratory distress syndrome. N Engl J Med 2000; 342: 1301–08.   
72 Guérin C, Reignier J, Richard J-CC, et al. Prone positioning in severe acute respiratory distress syndrome. N Engl J Med 2013; 368: 2159–68.   
73 Duggal A, Ganapathy A, Ratnapalan M, Adhikari NK. Pharmacological treatments for acute respiratory distress syndrome: systematic review. Minerva Anestesiol 2015; 81: 567–88.   
74 Reddy K, Sinha P, O’Kane CM, Gordon AC, Calfee CS, McAuley DF. Subphenotypes in critical care: translation into clinical practice. Lancet Respir Med 2020; 8: 631–43.   
75 Prescott HC, Calfee CS, Thompson BT, Angus DC, Liu VX. Toward smarter lumping and smarter splitting: rethinking strategies for sepsis and acute respiratory distress syndrome clinical trial design. Am J Respir Crit Care Med 2016; 194: 147–55.   
76 Bos L, Artigas A, Constatin J-M, et al. Precision medicine in acute respiratory distress syndrome: workshop report and recommendations for future research. Eur Respir Rev 2021; 30: 200317.   
77 Beitler JR, Thompson BT, Baron RM, et al. Advancing precision medicine for acute respiratory distress syndrome. Lancet Respir Med 2021; 2600: 1–14.   
78 Bos LDJ, Sinha P, Dickson RP. The perils of premature phenotyping in COVID-19: a call for caution. Eur Respir J 2020; 56: 2001768.   
79 Bos LDJ, Laffey JG, Ware LB, et al. Towards a biological definition of ARDS: are treatable traits the solution? Intensive Care Med Exp 2022; 10: 8.   
80 Ware LB, Matthay MA, Mebazaa A. Designing an ARDS trial for 2020 and beyond: focus on enrichment strategies. Intensive Care Med 2020; 46: 2153–56.   
81 Pelosi P, D’Onofrio D, Chiumello D, et al. Pulmonary and extrapulmonary acute respiratory distress syndrome are different. Eur Respir J Suppl 2003; 42 (suppl 42): 48s–56s.   
82 Peukert K, Fox M, Schulz S, et al. Inhibition of caspase-1 with tetracycline ameliorates acute lung injury. Am J Respir Crit Care Med 2021; 204: 53–63.   
83 Calfee CS, Janz DR, Bernard GR, et al. Distinct molecular phenotypes of direct vs indirect ARDS in single-center and multicenter studies. Chest 2015; 147: 1539–48.   
84 Gattinoni L, Pelosi P, Suter PM, Pedoto A, Vercesi P, Lissoni A. Acute respiratory distress syndrome caused by pulmonary and extrapulmonary disease. Different syndromes? Am J Respir Crit Care Med 1998; 158: 3–11.   
85 Gajic O, Rana R, Winters JL, et al. Transfusion-related acute lung injury in the critically ill: prospective nested case-control study. Am J Respir Crit Care Med 2007; 176: 886–91.   
86 Gajic O, Yilmaz M, Iscimen R, et al. Transfusion from male-only versus female donors in critically ill recipients of high plasma volume components. Crit Care Med 2007; 35: 1645–48.   
87 Eder AF, Herron RM Jr, Strupp A, et al. Effective reduction of transfusion-related acute lung injury risk with male-predominant plasma strategy in the American Red Cross (2006–2008). Transfusion 2010; 50: 1732–42.   
88 Wiersum-Osselton JC, Middelburg RA, Beckers EAM, et al. Male-only fresh-frozen plasma for transfusion-related acute lung injury prevention: before-and-after comparative cohort study. Transfusion 2011; 51: 1278–83.   
89 Juffermans NP, Aubron C, Duranteau J, et al. Transfusion in the mechanically ventilated patient. Intensive Care Med 2020; 46: 2450–57.   
90 Li G, Malinchoc M, Cartin-Ceba R, et al. Eight-year trend of acute respiratory distress syndrome: a population-based study in Olmsted County, Minnesota. Am J Respir Crit Care Med 2011; 183: 59–66.   
91 Pairo-Castineira E, Clohisey S, Klaric L, et al. Genetic mechanisms of critical illness in Covid-19. Nature 2021; 591: 92–98.   
92 Sarma A, Christenson SA, Byrne A, et al. Tracheal aspirate RNA sequencing identifies distinct immunological features of COVID-19 ARDS. Nat Commun 2021; 12: 5152.   
93 RECOVERY Collaborative Group. Dexamethasone in hospitalized patients with COVID-19 - preliminary report. N Engl J Med 2021; 384: 693–704.   
94 Gordon AC, Mouncey PR, Al-Beidh F, et al. Interleukin-6 receptor antagonists in critically ill patients with COVID-19. N Engl J Med 2021; 384: 1491–502.   
95 Kalil AC, Patterson TF, Mehta AK, et al. Baricitinib plus remdesivir for hospitalized adults with COVID-19. N Engl J Med 2021; 384: 795–807.   
96 Calfee CS, Delucchi K, Parsons PE, et al. Subphenotypes in acute respiratory distress syndrome: latent class analysis of data from two randomised controlled trials. Lancet Respir Med 2014; 2: 611–20.   
97 Bos LDJ, Schouten LR, van Vught LA, et al. Identification and validation of distinct biological phenotypes in patients with acute respiratory distress syndrome by cluster analysis. Thorax 2017; 72: 876–83.   
98 Famous KR, Delucchi K, Ware LB, et al. Acute respiratory distress syndrome subphenotypes respond differently to randomized fluid management strategy. Am J Respir Crit Care Med 2017; 195: 331–38.   
99 Calfee CS, Delucchi KL, Sinha P, et al. Acute respiratory distress syndrome subphenotypes and differential response to simvastatin: secondary analysis of a randomised controlled trial. Lancet Respir Med 2018; 6: 691–98.   
100 Sinha P, Delucchi KL, Thompson BT, McAuley DF, Matthay MA, Calfee CS. Latent class analysis of ARDS subphenotypes: a secondary analysis of the statins for acutely injured lungs from sepsis (SAILS) study. Intensive Care Med 2018; 44: 1859–69.   
101 Sinha P, Delucchi KL, Chen Y, et al. Latent class analysis-derived subphenotypes are generalisable to observational cohorts of acute respiratory distress syndrome: a prospective study. Thorax 2021; 77: 13–21.   
102 Sinha P, Delucchi KL, McAuley DF, O’Kane CM, Matthay MA, Calfee CS. Development and validation of parsimonious algorithms to classify acute respiratory distress syndrome phenotypes: a secondary analysis of randomised controlled trials. Lancet Respir Med 2020; 8: 247–257.   
103 Maddali MV, Churpek M, Pham T, et al. Validation and utility of ARDS subphenotypes identified by machine-learning models using clinical data: an observational, multicohort, retrospective analysis. Lancet Respir Med 2022; 10: 367–77.   
104 Sinha P, Churpek MM, Calfee CS. Machine learning classifier models can identify ARDS phenotypes using readily available clinical data. Am J Respir Crit Care Med 2020; 202: 996–1004.   
105 Hothersall E, McSharry C, Thomson NC. Potential therapeutic role for statins in respiratory disease. Thorax 2006; 61: 729–34.   
106 Bos LDJ, Scicluna BP, Ong DSY, Cremer O, van der Poll T, Schultz MJ. Understanding heterogeneity in biologic phenotypes of acute respiratory distress syndrome by leukocyte expression profiles. Am J Respir Crit Care Med 2019; 200: 42–50.   
107 Heijnen NFL, Hagens LA, Smit MR, et al. Biological subphenotypes of ARDS show prognostic enrichment in mechanically ventilated patients without ARDS. Am J Respir Crit Care Med 2021; 203: 1503–11.   
108 Heijnen NFL, Hagens LA, Smit MR, et al. Biological subphenotypes of acute respiratory distress syndrome may not reflect differences in alveolar inflammation. Physiol Rep 2021; 9: e14693.   
109 Constantin JM, Grasso S, Chanques G, et al. Lung morphology predicts response to recruitment maneuver in patients with acute respiratory distress syndrome. Crit Care Med 2010; 38: 1108–17.   
110 Constantin J-M, Jabaudon M, Lefrant J-Y, et al. Personalised mechanical ventilation tailored to lung morphology versus low positive end-expiratory pressure for patients with acute respiratory distress syndrome in France (the LIVE study): a multicentre, singleblind, randomised controlled trial. Lancet Respir Med 2019; 7: 870–80.   
111 Pierrakos C, Smit MR, Pisani L, Paulus F. Lung ultrasound assessment of focal and non-focal lung morphology in patients with acute respiratory distress syndrome. Front Physiol 2021; 12: 1–10.   
112 Wendel Garcia PD, Caccioppola A, Coppola S, et al. Latent class analysis to predict intensive care outcomes in acute respiratory distress syndrome: a proposal of two pulmonary phenotypes. Crit Care 2021; 25: 154.   
113 Delucchi K, Famous KR, Ware LB, Parsons PE, Thompson BT, Calfee CS. Stability of ARDS subphenotypes over time in two randomised controlled trials. Thorax 2018; 73: 439–45.   
114 Bos LDJ, Sjoding M, Sinha P, et al. Longitudinal respiratory subphenotypes in patients with COVID-19-related acute respiratory distress syndrome: results from three observational cohorts. Lancet Respir Med 2021; 9: 1377–86.   
115 van Vught LA, Bos LDJ. COVID-19 pathophysiology: an opportunity to start appreciating time-dependent variation. Am J Respir Crit Care Med 2022; 205: 483–85.